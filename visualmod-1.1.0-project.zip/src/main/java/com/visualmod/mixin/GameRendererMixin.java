package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** No Hurt Cam: камера не трясётся при получении урона. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.noHurtCam) ci.cancel();
    }
}
