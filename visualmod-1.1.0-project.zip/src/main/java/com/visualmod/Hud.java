package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** HUD: watermark, координаты, список модулей, клавиши (WASD) и Hit Info - каждый блок можно двигать. */
public final class Hud {
    private Hud() {}

    public enum Elem { WATERMARK, INFO, MODULES, KEYS, HITINFO }

    public static final int H = 15;      // высота плашки
    private static final int ROW = 16;   // шаг строки в списке модулей
    private static final int KEY = 18, KGAP = 2, SPACE_H = 12;
    private static final int HIT_W = 126, HIT_H = 36;
    private static final int BG = 0xB0101018;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFFA0A0B2;
    private static final int RED = 0xFFFF6B6B;
    private static final int GREEN = 0xFF69F0AE;

    // ------------------------------------------------------------ рендер

    public static void render(DrawContext c, RenderTickCounter tickCounter) {
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        Screen s = mc.currentScreen;
        if (s instanceof HudEditorScreen) return;   // редактор рисует сам

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        if (Config.hudWatermark) draw(c, mc, Elem.WATERMARK, sw, sh, false);
        if (Config.hudInfo) draw(c, mc, Elem.INFO, sw, sh, false);
        if (Config.hudModuleList) {
            if (!modules(false).isEmpty()) draw(c, mc, Elem.MODULES, sw, sh, false);
        }
        if (Config.hudKeys) draw(c, mc, Elem.KEYS, sw, sh, false);
        if (Config.hitInfo && HitInfo.active()) draw(c, mc, Elem.HITINFO, sw, sh, false);
    }

    // ------------------------------------------------------------ геометрия

    public static int width(MinecraftClient mc, Elem e, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        switch (e) {
            case WATERMARK: {
                String rest = watermarkRest(mc);
                int w = 9 + Ui.width(tr, "VisualMod") + 9;
                if (!rest.isEmpty()) w += 8 + Ui.width(tr, rest);
                return w;
            }
            case INFO:
                return 18 + Ui.width(tr, xyz(mc));
            case KEYS:
                return KEY * 3 + KGAP * 2;
            case HITINFO:
                return HIT_W;
            default: {
                int max = 0;
                for (String m : modules(preview)) max = Math.max(max, Ui.width(tr, m) + 22);
                return max;
            }
        }
    }

    public static int height(MinecraftClient mc, Elem e, boolean preview) {
        if (e == Elem.MODULES) {
            int n = modules(preview).size();
            return n == 0 ? 0 : n * ROW - 2;
        }
        if (e == Elem.KEYS) return KEY * 2 + KGAP * 2 + SPACE_H;
        if (e == Elem.HITINFO) return HIT_H;
        return H;
    }

    /** Левый край блока на экране с учётом границ. */
    public static int left(MinecraftClient mc, Elem e, int sw, boolean preview) {
        int w = width(mc, e, preview);
        int x = Config.hudX[e.ordinal()];
        int l = e == Elem.MODULES ? (x < 0 ? sw - 4 : x) - w : x;
        return Math.max(0, Math.min(l, Math.max(0, sw - w)));
    }

    public static int top(MinecraftClient mc, Elem e, int sh, boolean preview) {
        int h = height(mc, e, preview);
        return Math.max(0, Math.min(Config.hudY[e.ordinal()], Math.max(0, sh - h)));
    }

    public static void setPos(MinecraftClient mc, Elem e, int left, int top, boolean preview) {
        int w = width(mc, e, preview);
        Config.hudX[e.ordinal()] = e == Elem.MODULES ? left + w : left;
        Config.hudY[e.ordinal()] = top;
    }

    // ------------------------------------------------------------ содержимое

    private static String watermarkRest(MinecraftClient mc) {
        if (!Config.hudInfo) return "";
        String rest = mc.getCurrentFps() + " fps";
        int ping = ping(mc);
        if (ping >= 0) rest += "  |  " + ping + " ms";
        return rest;
    }

    private static String xyz(MinecraftClient mc) {
        if (mc.player == null) return "XYZ  0  0  0";
        return String.format("XYZ  %d  %d  %d",
                (int) Math.floor(mc.player.getX()),
                (int) Math.floor(mc.player.getY()),
                (int) Math.floor(mc.player.getZ()));
    }

    public static List<String> modules(boolean preview) {
        List<String> mods = new ArrayList<>();
        if (preview || Config.esp) mods.add("ESP");
        if (preview || Config.seeInvisibles) mods.add("SeeInvisibles");
        if (preview || Config.fullbright) mods.add("Fullbright");
        if (preview || Config.nameTags) mods.add("NameTags");
        if (preview || Config.itemPhysics) mods.add("ItemPhysics");
        if (preview || Config.jumpCircle) mods.add("JumpCircle");
        if (preview || Config.chinaHat) mods.add("ChinaHat");
        if (preview || Config.noParticles) mods.add("NoParticles");
        if (preview || Config.noHurtCam) mods.add("NoHurtCam");
        if (preview || Config.viewModel) mods.add("ViewModel");
        if (preview || Config.swingAnim) mods.add("Swing");
        if (preview || Config.hitInfo) mods.add("HitInfo");
        if (preview || Config.autoTotem) mods.add("AutoTotem");
        if (preview || Config.clickPearl) mods.add("ClickPearl");
        if (preview || Config.clickWind) mods.add("ClickWind");
        if (preview || Config.autoSprint) mods.add("AutoSprint");
        if (preview || Config.autoRespawn) mods.add("AutoRespawn");
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        mods.sort(Comparator.comparingInt((String a) -> Ui.width(tr, a)).reversed());
        return mods;
    }

    // ------------------------------------------------------------ рисование блока

    public static void draw(DrawContext c, MinecraftClient mc, Elem e, int sw, int sh, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        int accent = Config.accent();
        int x = left(mc, e, sw, preview);
        int y = top(mc, e, sh, preview);
        int w = width(mc, e, preview);

        switch (e) {
            case WATERMARK: {
                Ui.capsule(c, x, y, w, H, BG);
                int tx = x + 9;
                Ui.textMid(c, tr, "VisualMod", tx, y, H, accent);
                tx += Ui.width(tr, "VisualMod");
                String rest = watermarkRest(mc);
                if (!rest.isEmpty()) Ui.textMid(c, tr, rest, tx + 8, y, H, MUTED);
                break;
            }
            case INFO: {
                Ui.capsule(c, x, y, w, H, BG);
                Ui.capsule(c, x + 6, y + (H - 5) / 2, 5, 5, accent);
                Ui.textMid(c, tr, xyz(mc), x + 15, y, H, MUTED);
                break;
            }
            case KEYS: {
                key(c, mc, "W", mc.options.forwardKey.isPressed(), x + KEY + KGAP, y, KEY, KEY, accent);
                key(c, mc, "A", mc.options.leftKey.isPressed(), x, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "S", mc.options.backKey.isPressed(), x + KEY + KGAP, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "D", mc.options.rightKey.isPressed(), x + (KEY + KGAP) * 2, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "", mc.options.jumpKey.isPressed(), x, y + (KEY + KGAP) * 2, w, SPACE_H, accent);
                break;
            }
            case HITINFO:
                drawHit(c, tr, x, y, w, preview, accent);
                break;
            default: {
                int right = x + w;
                int ry = y;
                for (String m : modules(preview)) {
                    int rw = Ui.width(tr, m) + 22;
                    int rh = ROW - 2;
                    Ui.capsule(c, right - rw, ry, rw, rh, BG);
                    Ui.capsule(c, right - rw + 7, ry + (rh - 4) / 2, 4, 4, accent);
                    Ui.textMid(c, tr, m, right - rw + 15, ry, rh, TEXT);
                    ry += ROW;
                }
            }
        }
    }

    private static void drawHit(DrawContext c, TextRenderer tr, int x, int y, int w, boolean preview, int accent) {
        String name = preview ? "Player" : HitInfo.name();
        float hp = preview ? 14.0f : HitInfo.hp;
        float max = preview ? 20.0f : HitInfo.maxHp;
        float dealt = preview ? 12.5f : HitInfo.dealt;
        float healed = preview ? 4.0f : HitInfo.healed;
        float last = preview ? 3.5f : HitInfo.lastHit;

        Ui.shadow(c, x, y, w, HIT_H, 9);
        Ui.rrect(c, x, y, w, HIT_H, 9, BG);

        if (Config.hiName) Ui.textMid(c, tr, name, x + 10, y + 2, 14, accent);
        String hpText = String.format("%.1f", hp);
        Ui.textMid(c, tr, hpText, x + w - 10 - Ui.width(tr, hpText), y + 2, 14, TEXT);

        String d = "-" + String.format("%.1f", dealt);
        String h = "+" + String.format("%.1f", healed);
        Ui.textMid(c, tr, d, x + 10, y + 15, 14, RED);
        if (last > 0.0f) {
            String l = "(" + String.format("%.1f", last) + ")";
            Ui.textMid(c, tr, l, x + 14 + Ui.width(tr, d), y + 15, 14, MUTED);
        }
        Ui.textMid(c, tr, h, x + w - 10 - Ui.width(tr, h), y + 15, 14, GREEN);

        // полоска здоровья цели
        float frac = MathHelper.clamp(hp / Math.max(1.0f, max), 0.0f, 1.0f);
        int bw = w - 20;
        int hpColor = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);
        Ui.rrectF(c, x + 10, y + HIT_H - 6, bw, 3, 1.5f, 0x80000000);
        Ui.rrectF(c, x + 10, y + HIT_H - 6, Math.max(3.0f, bw * frac), 3, 1.5f, hpColor);
    }

    private static void key(DrawContext c, MinecraftClient mc, String label, boolean down,
                            int x, int y, int w, int h, int accent) {
        Ui.rrect(c, x, y, w, h, h / 2, down ? accent : BG);
        if (label.isEmpty()) {
            Ui.capsule(c, x + w / 2 - 8, y + h / 2 - 1, 16, 2, down ? 0xFFFFFFFF : MUTED);
        } else {
            int tw = Ui.width(mc.textRenderer, label);
            Ui.textMid(c, mc.textRenderer, label, x + (w - tw) / 2, y, h, down ? 0xFFFFFFFF : MUTED);
        }
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? -1 : e.getLatency();
    }
}
