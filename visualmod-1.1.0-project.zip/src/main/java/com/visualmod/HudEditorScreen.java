package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Редактор HUD: таскай блоки мышкой. Esc / Enter — вернуться в меню. */
public class HudEditorScreen extends Screen {
    private Hud.Elem drag = null;
    private int offX, offY;

    public HudEditorScreen() {
        super(Text.literal("VisualMod HUD"));
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        c.fill(0, 0, width, height, 0x60000000);
        int accent = Config.accent();

        for (Hud.Elem e : Hud.Elem.values()) {
            int x = Hud.left(client, e, width, true);
            int y = Hud.top(client, e, height, true);
            int w = Hud.width(client, e, true);
            int h = Hud.height(client, e, true);
            boolean hot = e == drag || (drag == null && Ui.in(mouseX, mouseY, x, y, w, h));
            if (hot) {
                boolean boxy = e == Hud.Elem.MODULES || e == Hud.Elem.KEYS || e == Hud.Elem.HITINFO;
                Ui.rrect(c, x - 3, y - 3, w + 6, h + 6, boxy ? 10 : (Hud.H + 6) / 2, (accent & 0xFFFFFF) | 0x90000000);
            }
            Hud.draw(c, client, e, width, height, true);
        }

        String hint = "Тащи блоки мышкой  -  Esc: назад";
        int tw = Ui.width(textRenderer, hint);
        int hw = tw + 24;
        Ui.capsule(c, (width - hw) / 2, height - 30, hw, 18, 0xE0101018);
        Ui.textMid(c, textRenderer, hint, (width - tw) / 2, height - 30, 18, 0xFFEDEDF5);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            Hud.Elem[] all = Hud.Elem.values();
            for (int i = all.length - 1; i >= 0; i--) {
                Hud.Elem e = all[i];
                int x = Hud.left(client, e, width, true);
                int y = Hud.top(client, e, height, true);
                if (Ui.in(mx, my, x, y, Hud.width(client, e, true), Hud.height(client, e, true))) {
                    drag = e;
                    offX = (int) mx - x;
                    offY = (int) my - y;
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag != null) {
            int w = Hud.width(client, drag, true);
            int h = Hud.height(client, drag, true);
            int nx = Math.max(0, Math.min((int) mx - offX, width - w));
            int ny = Math.max(0, Math.min((int) my - offY, height - h));
            Hud.setPos(client, drag, nx, ny, true);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        drag = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void close() {
        Config.save();
        client.setScreen(new ClickGuiScreen());
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
