package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * Меню мода. ЛКМ по модулю - вкл/выкл, ПРАВАЯ кнопка - окно настроек этого модуля.
 * Окно можно двигать за пустое место. Всё рисуется в нативном разрешении (без пикселей).
 */
public class ClickGuiScreen extends Screen {
    private static final int W = 384;
    private static final int H = 252;
    private static final int SIDE = 100;
    private static final int STRIDE = 22;   // шаг строк
    private static final int RH = 20;       // высота строки
    private static final int POP_W = 248;

    private static final int BORDER = 0xFF2C2C3A;
    private static final int BG = 0xFF14141B;
    private static final int SIDE_BG = 0xFF0E0E13;
    private static final int POP_BG = 0xFF181821;
    private static final int PANEL = 0xFF1E1E29;
    private static final int PANEL_HOVER = 0xFF2A2A38;
    private static final int OFF = 0xFF3C3C4C;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFF8E8E9F;

    private static int tab = 0;
    private static final String[] TAB_NAMES = {"Visuals", "World", "Hands", "Combat", "Misc", "HUD"};

    // позиция окна запоминается между открытиями
    private static boolean placed = false;
    private static int winX, winY;

    private final List<List<Row>> pages = new ArrayList<>();
    private Row dragging = null;
    private boolean movingWindow = false;
    private int px, py;

    // окно настроек модуля (ПКМ)
    private Toggle popup = null;
    private List<Row> popupRows = new ArrayList<>();
    private int popX, popY, popH;

    // строка выбора клавиши, которая сейчас ждёт нажатия
    private BindRow listening = null;

    public ClickGuiScreen() {
        super(Text.literal("noomidls"));
    }

    // ------------------------------------------------------------ строки меню

    private abstract class Row {
        int height() { return STRIDE; }
        abstract void render(DrawContext c, int x, int y, int w, int mx, int my);
        boolean click(int x, int y, int w, double mx, double my) { return false; }
        void drag(double mx) {}
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        List<Row> settings = null;   // != null -> у модуля есть окно настроек (ПКМ)

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        Toggle with(Row... rows) {
            this.settings = new ArrayList<>(Arrays.asList(rows));
            return this;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean on = get.getAsBoolean();
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, on ? TEXT : MUTED);

            int sw = 28, sh = 12;
            int sx = x + w - sw - 8;
            int sy = y + (RH - sh) / 2;
            Ui.capsule(c, sx, sy, sw, sh, on ? Config.accent() : OFF);
            int kx = on ? sx + sw - sh + 2 : sx + 2;
            Ui.capsule(c, kx, sy + 2, sh - 4, sh - 4, 0xFFFFFFFF);

            if (settings != null) {   // три точки = есть настройки
                for (int i = 0; i < 3; i++) {
                    Ui.capsule(c, sx - 16 + i * 4, y + RH / 2 - 1, 2, 2, MUTED);
                }
            }
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Cycle extends Row {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            String v = options[Math.floorMod(get.getAsInt(), options.length)];
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(Math.floorMod(get.getAsInt() + 1, options.length));
                return true;
            }
            return false;
        }
    }

    private class Slider extends Row {
        final String label;
        final float min, max;
        final String fmt;
        final Supplier<Float> get;
        final Consumer<Float> set;
        int trackX, trackW;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);

            String value = String.format(fmt, get.get());
            Ui.textMid(c, textRenderer, value, x + w - 12 - Ui.width(textRenderer, value), y, RH, MUTED);

            trackX = x + 74;
            trackW = w - 74 - 54;
            float t = (get.get() - min) / (max - min);
            t = Math.max(0f, Math.min(1f, t));
            float fill = trackW * t;
            int ty = y + (RH - 4) / 2;
            Ui.capsuleF(c, trackX, ty, trackW, 4, OFF);
            if (fill > 0) Ui.capsuleF(c, trackX, ty, Math.max(4.0f, fill), 4, Config.accent());
            Ui.capsuleF(c, trackX + fill - 4, y + (RH - 8) / 2.0f, 8, 8, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, trackX - 6, y, trackW + 12, RH)) {
                drag(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            float t = (float) ((mx - trackX) / trackW);
            t = Math.max(0f, Math.min(1f, t));
            set.accept(min + t * (max - min));
        }
    }

    private class Button extends Row {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean hov = Ui.in(mx, my, x, y, w, RH);
            Ui.capsule(c, x, y, w, RH, hov ? Config.accent() : PANEL_HOVER);
            int tw = Ui.width(textRenderer, label);
            Ui.textMid(c, textRenderer, label, x + (w - tw) / 2, y, RH, TEXT);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    /** Выбор клавиши / кнопки мыши. Клик -> нажми нужную кнопку. Esc = очистить. */
    private class BindRow extends Row {
        final String label;
        final IntSupplier get;
        final IntConsumer set;

        BindRow(String label, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        String name(int code) {
            if (code == -1) return "None";
            if (code <= -100) {
                int b = -100 - code;
                return b == 0 ? "LMB" : b == 1 ? "RMB" : b == 2 ? "MMB" : "Mouse " + (b + 1);
            }
            return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            boolean wait = listening == this;
            String v = wait ? "Press..." : name(get.getAsInt());
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, wait ? 0xFFFFFFFF : Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, wait ? 0xFF14141B : 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                listening = this;
                return true;
            }
            return false;
        }
    }

    private class Note extends Row {
        final String text;

        Note(String text) {
            this.text = text;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.textMid(c, textRenderer, text, x + 12, y, RH, MUTED);
        }
    }

    private class AccentPicker extends Row {
        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, "Accent color", x + 12, y, RH, TEXT);
            String name = Config.accentName();
            int nw = Ui.width(textRenderer, name);
            Ui.textMid(c, textRenderer, name, x + w - 12 - nw, y, RH, MUTED);
            Ui.capsule(c, x + w - 12 - nw - 16, y + (RH - 10) / 2, 10, 10, Config.accent());
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                Config.accent++;
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------ экран

    private Slider slider(String label, float min, float max, String fmt, Supplier<Float> g, Consumer<Float> s) {
        return new Slider(label, min, max, fmt, g, s);
    }

    private Toggle toggle(String label, BooleanSupplier g, Consumer<Boolean> s) {
        return new Toggle(label, g, s);
    }

    @Override
    protected void init() {
        pages.clear();
        popup = null;
        popupRows.clear();
        listening = null;

        // ---- Visuals
        List<Row> visuals = new ArrayList<>();
        visuals.add(toggle("ESP", () -> Config.esp, v -> Config.esp = v).with(
                new Cycle("Mode", new String[]{"Box", "Glow"}, () -> Config.espMode, v -> Config.espMode = v),
                toggle("Mobs (Box)", () -> Config.espMobs, v -> Config.espMobs = v),
                toggle("Fill", () -> Config.espFill, v -> Config.espFill = v),
                toggle("Health bar", () -> Config.espHealth, v -> Config.espHealth = v)));
        visuals.add(toggle("See invisibles", () -> Config.seeInvisibles, v -> Config.seeInvisibles = v).with(
                toggle("Players only", () -> Config.siPlayersOnly, v -> Config.siPlayersOnly = v)));
        visuals.add(toggle("NameTags", () -> Config.nameTags, v -> Config.nameTags = v).with(
                slider("Scale", 0.6f, 1.8f, "%.2f", () -> Config.ntScale, v -> Config.ntScale = v),
                toggle("Health", () -> Config.ntHealth, v -> Config.ntHealth = v),
                toggle("Distance", () -> Config.ntDistance, v -> Config.ntDistance = v)));
        visuals.add(toggle("Fullbright", () -> Config.fullbright, v -> Config.fullbright = v).with());
        visuals.add(toggle("Item Physics", () -> Config.itemPhysics, v -> Config.itemPhysics = v).with(
                slider("Spin", 0.0f, 3.0f, "%.1f", () -> Config.ipSpin, v -> Config.ipSpin = v)));
        pages.add(visuals);

        // ---- World
        List<Row> world = new ArrayList<>();
        world.add(toggle("Jump Circle", () -> Config.jumpCircle, v -> Config.jumpCircle = v).with(
                new Cycle("Color", Config.COLOR_MODES, () -> Config.jcColor, v -> Config.jcColor = v),
                slider("Radius", 0.8f, 3.5f, "%.1f", () -> Config.jcRadius, v -> Config.jcRadius = v),
                slider("Time", 0.4f, 2.5f, "%.1fs", () -> Config.jcDuration, v -> Config.jcDuration = v),
                toggle("Other players", () -> Config.jcOthers, v -> Config.jcOthers = v)));
        world.add(toggle("China Hat", () -> Config.chinaHat, v -> Config.chinaHat = v).with(
                new Cycle("Color", Config.COLOR_MODES, () -> Config.chColor, v -> Config.chColor = v),
                slider("Radius", 0.3f, 0.95f, "%.2f", () -> Config.chRadius, v -> Config.chRadius = v),
                slider("Height", 0.15f, 0.9f, "%.2f", () -> Config.chHeight, v -> Config.chHeight = v),
                slider("Opacity", 0.15f, 1.0f, "%.2f", () -> Config.chAlpha, v -> Config.chAlpha = v),
                toggle("Other players", () -> Config.chOthers, v -> Config.chOthers = v)));
        world.add(toggle("No Particles", () -> Config.noParticles, v -> Config.noParticles = v).with(
                new Note("Убирает ВСЕ частицы - больше FPS")));
        world.add(toggle("No Hurt Cam", () -> Config.noHurtCam, v -> Config.noHurtCam = v).with());
        pages.add(world);

        // ---- Hands
        List<Row> hands = new ArrayList<>();
        hands.add(toggle("ViewModel", () -> Config.viewModel, v -> Config.viewModel = v).with(
                slider("X", -1.0f, 1.0f, "%.2f", () -> Config.vmX, v -> Config.vmX = v),
                slider("Y", -1.0f, 1.0f, "%.2f", () -> Config.vmY, v -> Config.vmY = v),
                slider("Z", -1.5f, 0.5f, "%.2f", () -> Config.vmZ, v -> Config.vmZ = v),
                slider("Scale", 0.3f, 1.5f, "%.2f", () -> Config.vmScale, v -> Config.vmScale = v),
                new Button("Reset viewmodel", Config::resetViewModel)));
        hands.add(toggle("Swing Animation", () -> Config.swingAnim, v -> Config.swingAnim = v).with(
                new Cycle("Style", Config.SWING_STYLES, () -> Config.swingStyle, v -> Config.swingStyle = v),
                slider("Speed", 2.0f, 20.0f, "%.0f", () -> Config.swingSpeed, v -> Config.swingSpeed = (float) Math.round(v)),
                slider("Angle", -60.0f, 60.0f, "%.0f", () -> Config.swingAngle, v -> Config.swingAngle = (float) Math.round(v))));
        pages.add(hands);

        // ---- Combat
        List<Row> combat = new ArrayList<>();
        combat.add(toggle("Hit Info", () -> Config.hitInfo, v -> Config.hitInfo = v).with(
                slider("Hold", 3.0f, 30.0f, "%.0fs", () -> Config.hiHold, v -> Config.hiHold = (float) Math.round(v)),
                toggle("Show name", () -> Config.hiName, v -> Config.hiName = v),
                new Button("Reset stats", HitInfo::reset)));
        combat.add(toggle("Auto Totem", () -> Config.autoTotem, v -> Config.autoTotem = v).with(
                slider("Delay", 0.0f, 10.0f, "%.0ft", () -> Config.atDelay, v -> Config.atDelay = (float) Math.round(v)),
                slider("Health", 0.0f, 20.0f, "%.0f", () -> Config.atHealth, v -> Config.atHealth = (float) Math.round(v)),
                new Note("Health 0 = тотем всегда в левой руке")));
        combat.add(toggle("Click Pearl", () -> Config.clickPearl, v -> Config.clickPearl = v).with(
                new BindRow("Key", () -> Config.cpBind, v -> Config.cpBind = v),
                new Note("Бросает перл из хотбара и возвращает слот")));
        combat.add(toggle("Click Wind Charge", () -> Config.clickWind, v -> Config.clickWind = v).with(
                new BindRow("Key", () -> Config.cwBind, v -> Config.cwBind = v),
                toggle("Aim down", () -> Config.cwAimDown, v -> Config.cwAimDown = v)));
        pages.add(combat);

        // ---- Misc
        List<Row> misc = new ArrayList<>();
        misc.add(toggle("Auto Sprint", () -> Config.autoSprint, v -> Config.autoSprint = v).with());
        misc.add(toggle("Auto Respawn", () -> Config.autoRespawn, v -> Config.autoRespawn = v).with());
        pages.add(misc);

        // ---- HUD
        List<Row> hud = new ArrayList<>();
        hud.add(toggle("HUD", () -> Config.hud, v -> Config.hud = v));
        hud.add(toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v));
        hud.add(toggle("Module list", () -> Config.hudModuleList, v -> Config.hudModuleList = v));
        hud.add(toggle("Info (FPS, ping, XYZ)", () -> Config.hudInfo, v -> Config.hudInfo = v));
        hud.add(toggle("Keystrokes", () -> Config.hudKeys, v -> Config.hudKeys = v));
        hud.add(new Cycle("Font", Config.FONT_NAMES, () -> Config.font, v -> Config.font = v));
        hud.add(new AccentPicker());
        hud.add(new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())));
        hud.add(new Button("Reset HUD positions", Config::resetHud));
        pages.add(hud);

        if (!placed) {
            winX = (width - W) / 2;
            winY = (height - H) / 2;
            placed = true;
        }
        clampWindow();
    }

    private void clampWindow() {
        winX = Math.max(0, Math.min(winX, Math.max(0, width - W)));
        winY = Math.max(0, Math.min(winY, Math.max(0, height - H)));
        px = winX;
        py = winY;
    }

    private void openPopup(Toggle t) {
        popup = t;
        popupRows = new ArrayList<>();
        popupRows.add(new Toggle("Enabled", t.get, t.set));
        if (t.settings != null) popupRows.addAll(t.settings);
        if (t.settings == null || t.settings.isEmpty()) popupRows.add(new Note("Других настроек нет"));
        popH = 40 + popupRows.size() * STRIDE + 6;
        popX = px + (W - POP_W) / 2;
        popY = py + Math.max(8, (H - popH) / 2);
    }

    private void closePopup() {
        popup = null;
        popupRows.clear();
        listening = null;
        dragging = null;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        int accent = Config.accent();
        c.fill(0, 0, width, height, 0x70000000);

        // окно
        Ui.shadow(c, px, py, W, H, 17);
        Ui.rrect(c, px - 1, py - 1, W + 2, H + 2, 18, BORDER);
        Ui.rrect(c, px, py, W, H, 17, BG);

        int mx = popup != null ? -10000 : mouseX;
        int my = popup != null ? -10000 : mouseY;

        // боковая панель
        Ui.rrect(c, px + 6, py + 6, SIDE - 4, H - 12, 13, SIDE_BG);
        Ui.text(c, textRenderer, "noomi", px + 18, py + 18, TEXT);
        Ui.text(c, textRenderer, "dls", px + 18 + Ui.width(textRenderer, "noomi"), py + 18, accent);

        for (int i = 0; i < TAB_NAMES.length; i++) {
            int ty = py + 48 + i * 24;
            boolean sel = i == tab;
            boolean hov = Ui.in(mx, my, px + 12, ty, SIDE - 16, RH);
            if (sel) Ui.capsule(c, px + 12, ty, SIDE - 16, RH, accent);
            else if (hov) Ui.capsule(c, px + 12, ty, SIDE - 16, RH, PANEL_HOVER);
            Ui.textMid(c, textRenderer, TAB_NAMES[i], px + 24, ty, RH, sel ? 0xFFFFFFFF : MUTED);
        }
        Ui.text(c, textRenderer, "ПКМ - настройки", px + 18, py + H - 32, 0xFF5E5E70);
        Ui.text(c, textRenderer, "RShift - закрыть", px + 18, py + H - 20, 0xFF5E5E70);

        // содержимое вкладки
        int cx = px + SIDE + 10;
        int cw = W - SIDE - 20;
        Ui.text(c, textRenderer, TAB_NAMES[tab], cx + 4, py + 14, TEXT);
        Ui.capsule(c, cx, py + 26, cw, 2, PANEL);

        int y = py + 36;
        for (Row r : pages.get(tab)) {
            r.render(c, cx, y, cw, mx, my);
            y += r.height();
        }

        // окно настроек модуля
        if (popup != null) {
            Ui.rrect(c, px, py, W, H, 17, 0xA0000000);

            Ui.shadow(c, popX, popY, POP_W, popH, 14);
            Ui.rrect(c, popX - 1, popY - 1, POP_W + 2, popH + 2, 15, BORDER);
            Ui.rrect(c, popX, popY, POP_W, popH, 14, POP_BG);

            Ui.text(c, textRenderer, popup.label, popX + 14, popY + 12, accent);
            Ui.text(c, textRenderer, "settings", popX + 20 + Ui.width(textRenderer, popup.label), popY + 12, MUTED);
            Ui.capsule(c, popX + 10, popY + 26, POP_W - 20, 2, PANEL);

            int ry = popY + 36;
            for (Row r : popupRows) {
                r.render(c, popX + 10, ry, POP_W - 20, mouseX, mouseY);
                ry += r.height();
            }
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        // ждём кнопку для бинда: любая кнопка мыши назначается
        if (listening != null) {
            listening.set.accept(-100 - button);
            listening = null;
            return true;
        }

        if (popup != null) {
            boolean inside = Ui.in(mouseX, mouseY, popX, popY, POP_W, popH);
            if (button == 0 && inside) {
                int ry = popY + 36;
                for (Row r : popupRows) {
                    if (r.click(popX + 10, ry, POP_W - 20, mouseX, mouseY)) {
                        dragging = r;
                        break;
                    }
                    ry += r.height();
                }
                return true;
            }
            closePopup();
            return true;
        }

        if (button == 0) {
            for (int i = 0; i < TAB_NAMES.length; i++) {
                int ty = py + 48 + i * 24;
                if (Ui.in(mouseX, mouseY, px + 12, ty, SIDE - 16, RH)) {
                    tab = i;
                    return true;
                }
            }
        }

        int cx = px + SIDE + 10;
        int cw = W - SIDE - 20;
        int y = py + 36;
        for (Row r : pages.get(tab)) {
            if (button == 1 && r instanceof Toggle t && t.settings != null
                    && Ui.in(mouseX, mouseY, cx, y, cw, RH)) {
                openPopup(t);
                return true;
            }
            if (button == 0 && r.click(cx, y, cw, mouseX, mouseY)) {
                dragging = r;
                return true;
            }
            y += r.height();
        }
        // клик по пустому месту окна - тащим окно
        if (button == 0 && Ui.in(mouseX, mouseY, px, py, W, H)) {
            movingWindow = true;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mouseX);
            return true;
        }
        if (movingWindow) {
            winX += (int) Math.round(dx);
            winY += (int) Math.round(dy);
            int oldX = px, oldY = py;
            clampWindow();
            if (popup != null) {
                popX += px - oldX;
                popY += py - oldY;
            }
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        movingWindow = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (listening != null) {
            listening.set.accept(keyCode == GLFW.GLFW_KEY_ESCAPE ? -1 : keyCode);
            listening = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE && popup != null) {
            closePopup();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
