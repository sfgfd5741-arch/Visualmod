VisualMod 1.1.0 (Fabric 1.21.4, Loom 1.9, yarn-маппинги)

Сборка:  gradle build   (или ./gradlew build, если wrapper уже есть в вашем проекте)
Jar:     build/libs/visualmod-1.1.0.jar

Если у вас уже есть свой проект - просто замените src/main/java и src/main/resources
файлами из этого архива. Версии в gradle.properties поправьте под свои.
