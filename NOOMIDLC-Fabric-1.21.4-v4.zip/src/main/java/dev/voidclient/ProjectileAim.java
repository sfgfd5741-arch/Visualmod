package dev.voidclient;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;

/**
 * Projectile Aim: помощь в прицеливании для лука, арбалета, трезубца и бросаемых предметов
 * (снежок, яйцо, жемчуг эндера). Считает баллистику (скорость, гравитация, сопротивление воздуха),
 * упреждение по скорости цели и плавно доводит прицел до точки попадания.
 */
public final class ProjectileAim {
    private ProjectileAim() {}

    private record Ballistics(float speed, double gravity, double drag) {}

    private static final Map<Integer, Vec3d> LAST = new HashMap<>();
    private static final Map<Integer, Vec3d> VEL = new HashMap<>();

    private static LivingEntity target = null;
    private static Vec3d marker = null;
    private static float markerAlpha = 0.0f;

    public static LivingEntity target() {
        return target;
    }

    // ------------------------------------------------------------ какое оружие в руках

    private static Ballistics current(MinecraftClient mc, ClientPlayerEntity p) {
        ItemStack st = p.isUsingItem() ? p.getActiveItem() : p.getMainHandStack();
        Item it = st.getItem();
        boolean use = p.isUsingItem();

        if (it == Items.BOW && Config.paBow) {
            if (!use && Config.paOnlyUse) return null;
            return new Ballistics(3.0f, 0.05, 0.99);            // расчёт на полный натяг
        }
        if (it == Items.CROSSBOW && Config.paCrossbow) {
            if (!CrossbowItem.isCharged(st) && !use) return null;
            return new Ballistics(3.15f, 0.05, 0.99);
        }
        if (it == Items.TRIDENT && Config.paTrident) {
            if (!use && Config.paOnlyUse) return null;
            return new Ballistics(2.5f, 0.05, 0.99);
        }
        if ((it == Items.SNOWBALL || it == Items.EGG || it == Items.ENDER_PEARL) && Config.paThrown) {
            if (Config.paOnlyUse && !mc.options.useKey.isPressed()) return null;
            return new Ballistics(1.5f, 0.03, 0.99);
        }
        return null;
    }

    // ------------------------------------------------------------ логика

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) {
            LAST.clear();
            VEL.clear();
            target = null;
            marker = null;
            return;
        }
        trackVelocities(mc, p);

        if (!Config.projAim || mc.currentScreen != null || p.isSpectator() || !p.isAlive()) {
            target = null;
            marker = null;
            return;
        }
        Ballistics b = current(mc, p);
        if (b == null) {
            target = null;
            marker = null;
            return;
        }

        Vec3d start = p.getEyePos().add(0.0, -0.1, 0.0);
        LivingEntity best = null;
        Vec3d bestPoint = null;
        float bestPitch = 0.0f, bestYaw = 0.0f;
        double bestAngle = Double.MAX_VALUE;

        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class,
                p.getBoundingBox().expand(Config.paRange), x -> valid(p, x))) {
            if (p.distanceTo(e) > Config.paRange || !p.canSee(e)) continue;

            double ang = Math.abs(yawTo(p, e.getPos()));
            if (ang > Config.paFov / 2.0) continue;
            if (ang >= bestAngle) continue;

            float[] sol = solve(start, e, b);
            if (sol == null) continue;
            best = e;
            bestAngle = ang;
            bestYaw = sol[0];
            bestPitch = sol[1];
            bestPoint = new Vec3d(sol[2], sol[3], sol[4]);
        }

        target = best;
        marker = bestPoint;
        if (best == null) return;

        // плавный доворот без рывков: доля оставшегося угла + мёртвая зона
        float dyaw = MathHelper.wrapDegrees(bestYaw - p.getYaw());
        float dpitch = bestPitch - p.getPitch();
        float k = MathHelper.clamp(Config.paSmooth, 0.05f, 1.0f);
        float sy = Math.abs(dyaw) < 0.25f ? 0.0f : MathHelper.clamp(dyaw * k, -25.0f, 25.0f);
        float sp = Math.abs(dpitch) < 0.25f ? 0.0f : MathHelper.clamp(dpitch * k, -25.0f, 25.0f);
        if (sy != 0.0f || sp != 0.0f) {
            p.setYaw(p.getYaw() + sy);
            p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90.0f, 90.0f));
        }
    }

    private static boolean valid(ClientPlayerEntity p, LivingEntity e) {
        if (e == p || !e.isAlive() || e.isSpectator() || e instanceof ArmorStandEntity) return false;
        if (e instanceof PlayerEntity) return true;
        return Config.paMobs;
    }

    /** Скорость цели за тик: разница позиций, сглаженная. */
    private static void trackVelocities(MinecraftClient mc, ClientPlayerEntity p) {
        if (!Config.projAim) {
            LAST.clear();
            VEL.clear();
            return;
        }
        Map<Integer, Vec3d> now = new HashMap<>();
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(Config.paRange), x -> x != p)) {
            Vec3d pos = e.getPos();
            Vec3d prev = LAST.get(e.getId());
            if (prev != null) {
                Vec3d v = pos.subtract(prev);
                Vec3d old = VEL.get(e.getId());
                VEL.put(e.getId(), old == null ? v : old.multiply(0.5).add(v.multiply(0.5)));
            }
            now.put(e.getId(), pos);
        }
        LAST.clear();
        LAST.putAll(now);
        VEL.keySet().retainAll(now.keySet());
    }

    // ------------------------------------------------------------ баллистика

    /** @return {yaw, pitch, px, py, pz} или null, если до цели снаряд не долетит. */
    private static float[] solve(Vec3d start, LivingEntity e, Ballistics b) {
        Vec3d v = Config.paPredict ? VEL.getOrDefault(e.getId(), Vec3d.ZERO) : Vec3d.ZERO;
        double vy = e.isOnGround() ? 0.0 : MathHelper.clamp(v.y, -0.8, 0.8);
        Vec3d center = new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ());

        double flight = center.distanceTo(start) / b.speed();   // первое приближение, в тиках
        Vec3d point = center;
        float yaw = 0.0f, pitch = 0.0f;

        for (int iter = 0; iter < 3; iter++) {
            point = center.add(v.x * flight, vy * flight, v.z * flight);
            double[] r = bestElevation(start, point, b);
            if (r == null) return null;
            flight = r[1];
            pitch = (float) -r[0];
            double dx = point.x - start.x, dz = point.z - start.z;
            yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        }
        return new float[]{yaw, pitch, (float) point.x, (float) point.y, (float) point.z};
    }

    /** Перебор углов возвышения: берём тот, при котором снаряд подходит к точке ближе всего. @return {градусы вверх, тики} */
    private static double[] bestElevation(Vec3d start, Vec3d point, Ballistics b) {
        double dx = point.x - start.x, dz = point.z - start.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz < 0.01) return null;
        double ux = dx / horiz, uz = dz / horiz;

        double bestD2 = Double.MAX_VALUE, bestElev = 0.0, bestT = 0.0;
        int maxTicks = 140;
        double lo = Config.paGravity ? -60.0 : Math.toDegrees(Math.atan2(point.y - start.y, horiz));
        double hi = Config.paGravity ? 70.0 : lo;
        double step = Config.paGravity ? 0.4 : 1.0;

        for (double elev = lo; elev <= hi; elev += step) {
            double rad = Math.toRadians(elev);
            double vh = Math.cos(rad) * b.speed();
            double vyy = Math.sin(rad) * b.speed();
            double x = 0.0, y = 0.0;                    // x - вдоль горизонтали
            double tx = horiz, ty = point.y - start.y;

            for (int t = 1; t <= maxTicks; t++) {
                double nx = x + vh, ny = y + vyy;
                // ближайшая точка отрезка (x,y)->(nx,ny) к цели
                double sx = nx - x, sy = ny - y;
                double len2 = sx * sx + sy * sy;
                double u = len2 < 1e-9 ? 0.0 : MathHelper.clamp(((tx - x) * sx + (ty - y) * sy) / len2, 0.0, 1.0);
                double cx = x + sx * u, cy = y + sy * u;
                double d2 = (cx - tx) * (cx - tx) + (cy - ty) * (cy - ty);
                if (d2 < bestD2) {
                    bestD2 = d2;
                    bestElev = elev;
                    bestT = t - 1 + u;
                }
                x = nx;
                y = ny;
                vh *= b.drag();
                vyy = vyy * b.drag() - b.gravity();
                if (x > horiz + 4.0 && vyy < 0.0) break;   // уже пролетели цель
                if (y < ty - 40.0) break;
            }
        }
        if (bestD2 > 2.25) return null;   // дальше 1.5 блока от цели - не долетит
        return new double[]{bestElev, bestT};
    }

    private static double yawTo(ClientPlayerEntity p, Vec3d to) {
        double dx = to.x - p.getX(), dz = to.z - p.getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        return MathHelper.wrapDegrees(yaw - p.getYaw());
    }

    // ------------------------------------------------------------ метка точки попадания

    public static void render(WorldRenderContext ctx) {
        markerAlpha = Anim.smooth(markerAlpha, (Config.projAim && Config.paMark && marker != null) ? 1.0f : 0.0f, 14.0f);
        if (markerAlpha <= 0.02f || marker == null) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        Quaternionf rot = ctx.camera().getRotation();
        Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f).rotate(rot);
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f).rotate(rot);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ms.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        float pulse = 0.8f + 0.2f * (float) Math.sin(System.currentTimeMillis() / 160.0);
        float dist = (float) marker.distanceTo(cam);
        float s = Math.max(0.12f, dist * 0.018f) * pulse;      // постоянный размер на экране
        int rgb = Config.accent() & 0xFFFFFF;

        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        quad(b, mat, marker, right, up, s * 2.4f, rgb, 0.22f * markerAlpha);
        quad(b, mat, marker, right, up, s * 0.9f, 0xFFFFFF, 0.95f * markerAlpha);
        Ui.flush(b);

        RenderSystem.enableDepthTest();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private static void quad(BufferBuilder b, Matrix4f m, Vec3d c, Vector3f r, Vector3f u, float s, int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        int col = (a << 24) | (rgb & 0xFFFFFF);
        float x = (float) c.x, y = (float) c.y, z = (float) c.z;
        b.vertex(m, x + (-r.x - u.x) * s, y + (-r.y - u.y) * s, z + (-r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x - u.x) * s, y + (r.y - u.y) * s, z + (r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x + u.x) * s, y + (r.y + u.y) * s, z + (r.z + u.z) * s).color(col);
        b.vertex(m, x + (-r.x + u.x) * s, y + (-r.y + u.y) * s, z + (-r.z + u.z) * s).color(col);
    }
}
