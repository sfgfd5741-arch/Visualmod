package dev.voidclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;

/**
 * Legit Aura: "человеческая" аура. Обычный reach (3 м), плавный прицел с лёгкой неровностью,
 * удар только когда прицел реально на цели (по лучу), случайные задержки, опционально только криты.
 */
public final class LegitAura {
    private LegitAura() {}

    private static final Random R = new Random();
    private static LivingEntity target = null;
    private static int wait = 0;
    private static int nextDelay = 1;

    public static LivingEntity target() {
        return target;
    }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (!Config.legitAura || Config.killAura || p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || p.isSpectator() || !p.isAlive()) {
            target = null;
            wait = 0;
            if (!Config.killAura) Crit.release(mc);
            return;
        }

        target = pick(mc, p);
        if (target == null) {
            wait = 0;
            Crit.release(mc);
            return;
        }

        aim(p, target);

        if (p.isUsingItem()) return;
        if (Config.laCrits) {
            Crit.prepare(mc, p);
            if (!Crit.ready(p)) return;
        } else {
            Crit.release(mc);
        }
        if (p.getAttackCooldownProgress(0.5f) < 0.94f) return;
        // бьём только если прицел реально на цели
        if (!(mc.crosshairTarget instanceof EntityHitResult ehr) || ehr.getEntity() != target) return;
        if (wait++ < nextDelay) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        wait = 0;
        nextDelay = R.nextInt(3);   // 0..2 тика случайной паузы
    }

    private static LivingEntity pick(MinecraftClient mc, ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        double range = Config.laRange;
        LivingEntity best = null;
        double bestAng = 1.0e9;
        for (LivingEntity e : mc.world.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range + 1.0), x -> valid(p, x))) {
            if (dist(eye, e) > range) continue;
            if (!Config.laWalls && !p.canSee(e)) continue;
            double ang = Math.abs(yawDiff(p, e));
            if (ang > Config.laFov / 2.0f) continue;
            if (ang < bestAng) {
                bestAng = ang;
                best = e;
            }
        }
        return best;
    }

    private static boolean valid(ClientPlayerEntity p, LivingEntity e) {
        if (e == p || !e.isAlive() || !e.isAttackable() || e instanceof ArmorStandEntity || e.isSpectator()) return false;
        if (e.isInvisible()) return false;
        if (e instanceof PlayerEntity) return Config.laPlayers;
        if (e instanceof HostileEntity || e instanceof Monster) return Config.laMobs;
        return false;
    }

    private static double dist(Vec3d eye, LivingEntity e) {
        Box b = e.getBoundingBox();
        double x = MathHelper.clamp(eye.x, b.minX, b.maxX);
        double y = MathHelper.clamp(eye.y, b.minY, b.maxY);
        double z = MathHelper.clamp(eye.z, b.minZ, b.maxZ);
        return eye.distanceTo(new Vec3d(x, y, z));
    }

    private static float yawDiff(ClientPlayerEntity p, LivingEntity e) {
        double dx = e.getX() - p.getX();
        double dz = e.getZ() - p.getZ();
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        return MathHelper.wrapDegrees(yaw - p.getYaw());
    }

    /** Плавный поворот: доля оставшегося угла, лёгкая случайность, мёртвая зона, лимит скорости. */
    private static void aim(ClientPlayerEntity p, LivingEntity t) {
        Vec3d eye = p.getEyePos();
        double wob = System.currentTimeMillis() / 700.0;
        double ox = Math.sin(wob) * t.getWidth() * 0.18;
        double oy = Math.sin(wob * 1.3 + 1.0) * t.getHeight() * 0.08;
        Vec3d to = new Vec3d(t.getX() + ox, t.getY() + t.getHeight() * 0.65 + oy, t.getZ());
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (MathHelper.atan2(dz, dx) * 57.29577951308232) - 90.0f;
        float pitch = (float) -(MathHelper.atan2(dy, flat) * 57.29577951308232);

        float dyaw = MathHelper.wrapDegrees(yaw - p.getYaw());
        float dpitch = pitch - p.getPitch();
        float dead = 0.9f;
        float k = MathHelper.clamp(Config.laSmooth * (0.85f + R.nextFloat() * 0.3f), 0.05f, 1.0f);
        float max = 9.0f;
        float sy = Math.abs(dyaw) < dead ? 0.0f : MathHelper.clamp(dyaw * k, -max, max);
        float sp = Math.abs(dpitch) < dead ? 0.0f : MathHelper.clamp(dpitch * k * 0.8f, -max, max);
        if (sy == 0.0f && sp == 0.0f) return;
        p.setYaw(p.getYaw() + sy);
        p.setPitch(MathHelper.clamp(p.getPitch() + sp, -90.0f, 90.0f));
    }
}
