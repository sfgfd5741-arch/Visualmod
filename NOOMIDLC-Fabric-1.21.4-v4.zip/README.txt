Noomi DLC 3.1.0 — Fabric / Minecraft 1.21.4

Branding:
- Mod ID: noomi_dlc
- Display name: Noomi DLC
- Default accent: Violet
- Menu key: Right Shift
- Java: 21

Feature groups already present in this source:
- Visuals: ESP variants, invisibles, NameTags, Fullbright, item physics.
- World: custom sky/time, stretch, ambient particles, cinematic effects,
  jump circles, China Hat, block ESP and block effects.
- Hands: ViewModel and swing animation.
- Combat: Kill Aura, Legit Aura, Hit Info, Trigger Bot, Auto Totem,
  Pearl/Wind Charge hotkeys, Projectile Aim, Aim Assist and Kill Effects.
- Player: Auto Tool (automatically chooses the best hotbar tool while mining).\n- Movement / Misc: Inventory Move, Fly, Spider, No Web, Air Swim,
  Air Stuck, Reach, No Fall, Jesus, Anti-AFK, No Clip, Auto Sprint,
  Auto Respawn and Zoom.
- HUD: watermark, FPS, ping, module list, coordinates, keystrokes,
  armor, target HUD, player radar, compass, dimension, low-health warning,
  custom crosshair, potions and item counters.
- Style: multiple accent palettes, animated GUI, particles, glow and ripple.

Controls:
- Right Shift opens the ClickGUI.
- Left click toggles modules; right click opens module settings.
- Escape closes the menu.

Build:
- Use JDK 21.
- Open the project in IntelliJ IDEA / Gradle or run `gradle build`.
- The JAR is produced in build/libs/.
- Install Fabric Loader and Fabric API for Minecraft 1.21.4, then copy
  the built JAR to .minecraft/mods.

Note:
The archive contains source code. A successful build and in-game test have
not been performed in this environment. Some features may behave differently
in single-player and on multiplayer servers; server-side anti-cheat rules apply.
\nVersion note: Auto Tool was added as a real client tick module and is configurable in ClickGUI > Misc. This source archive has not been compiled or tested in-game here.\n