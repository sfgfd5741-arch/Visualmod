NOOMIDLC 3.2.0 — Fabric / Minecraft 1.21.4

Брендинг:
- Название: NOOMIDLC
- Mod ID: noomi_dlc
- Minecraft: 1.21.4
- Fabric Loader + Fabric API
- Java: 21
- Меню: Right Shift
- Цвет интерфейса: фиолетовый / чёрный

Что уже есть в исходниках:
- Combat: Kill Aura, Legit Aura, Trigger Bot, Aim Assist, Projectile Aim,
  Hit Info, Auto Totem, Kill Effects.
- Visuals: ESP, NameTags, Fullbright, Block ESP, Crosshair, No Hurt Cam,
  No Fire, No Particles, Item Physics.
- Movement / Player: Fly, Spider, No Web, Air Swim, Air Stuck, Reach,
  No Fall, Jesus, No Clip, Auto Sprint, Auto Tool, Anti-AFK.
- World: Custom Sky, Ambient, Cinematic, Stretch, Jump Circle, China Hat,
  Block Effects.
- HUD: watermark, FPS, ping, coordinates, keystrokes, armor, target HUD,
  module list, player radar, compass, dimension and other overlays.
- Interface: ClickGUI, configurable modules, keybinds and visual settings.

Важно про WexSide:
WexSide pack рассчитан на другую версию Minecraft (1.21.11) и содержит
закрытый клиентский JAR с условием All rights reserved. Его код и бинарник
не включены в этот проект. NOOMIDLC сохраняет собственную реализацию
похожих по назначению функций; это не перенос исходников WexSide.

Сборка:
1. Установи JDK 21.
2. Открой папку проекта в IntelliJ IDEA как Gradle-проект.
3. Запусти задачу Gradle: build.
4. Готовый JAR будет в build/libs/.
5. Для игры нужны Fabric Loader и Fabric API именно для Minecraft 1.21.4.
6. Скопируй JAR в .minecraft/mods.

Управление:
- Right Shift — открыть/закрыть ClickGUI.
- ЛКМ — включить/выключить модуль.
- ПКМ — настройки модуля (если доступны).
- В меню клавиш можно назначить бинды.

Ограничения:
Это архив исходного проекта, а не проверенный готовый JAR. В этой среде
сборка и запуск Minecraft не подтверждены. Перед использованием собери
проект и проверь его в отдельном профиле. Поведение некоторых функций
зависит от сервера и его античита.
