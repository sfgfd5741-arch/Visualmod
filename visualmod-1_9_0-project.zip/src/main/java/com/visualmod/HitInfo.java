package com.visualmod;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.ActionResult;

/**
 * Hit Info: цель, по которой ты бил, сколько с неё снялось здоровья (урон)
 * и сколько она восстановила (золотые яблоки, зелья, регенерация).
 * Считается по разнице HP + поглощения от тика к тику.
 */
public final class HitInfo {
    private HitInfo() {}

    private static LivingEntity target;
    private static String name = "";
    private static float prev;
    private static long lastActive;

    public static float dealt;     // всего снято с цели
    public static float healed;    // всего восстановлено целью
    public static float lastHit;   // последний снятый кусок
    public static float hp;
    public static float maxHp = 20.0f;

    public static void init() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient && Config.hitInfo
                    && entity instanceof LivingEntity le && !(entity instanceof ArmorStandEntity)) {
                attack(le);
            }
            return ActionResult.PASS;
        });
    }

    private static float health(LivingEntity e) {
        return e.getHealth() + e.getAbsorptionAmount();
    }

    private static void attack(LivingEntity le) {
        if (le != target) {
            target = le;
            name = le.getName().getString();
            dealt = 0.0f;
            healed = 0.0f;
            lastHit = 0.0f;
            prev = health(le);
        }
        hp = health(le);
        maxHp = Math.max(1.0f, le.getMaxHealth());
        lastActive = System.currentTimeMillis();
    }

    public static void tick(MinecraftClient mc) {
        if (!Config.hitInfo || mc.world == null) {
            target = null;
            return;
        }
        if (target == null) return;

        long now = System.currentTimeMillis();
        if (!target.isRemoved()) {
            float cur = health(target);
            float d = cur - prev;
            if (d < -0.01f) {
                dealt += -d;
                lastHit = -d;
                lastActive = now;
            } else if (d > 0.01f) {
                healed += d;
                lastActive = now;
            }
            prev = cur;
            hp = cur;
            maxHp = Math.max(1.0f, target.getMaxHealth());
        }
        if (now - lastActive > (long) (Config.hiHold * 1000.0f)) target = null;
    }

    public static boolean active() {
        return target != null;
    }

    public static String name() {
        return name;
    }

    public static void reset() {
        target = null;
        dealt = 0.0f;
        healed = 0.0f;
        lastHit = 0.0f;
    }
}
