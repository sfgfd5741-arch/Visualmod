package com.visualmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Box ESP: рамка с уголками и полоской здоровья вокруг игроков (и по желанию мобов).
 * Позиции считаются в мировом рендере, рисуются в HUD, поэтому рамка видна и сквозь стены.
 * Линии рисуются в физических пикселях окна - без "лесенки" GUI-масштаба.
 */
public final class Esp {
    private Esp() {}

    private record Frame(float x1, float y1, float x2, float y2, float hp, boolean player) {}

    private static final List<Frame> FRAMES = new ArrayList<>();

    public static boolean boxMode() {
        return Config.esp && Config.espMode == 0;
    }

    public static void collect(WorldRenderContext ctx) {
        FRAMES.clear();
        if (!boxMode()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !Config.espMobs) continue;
            if (!le.isAlive()) continue;

            Vec3d lerp = e.getLerpedPos(td);
            Vec3d off = lerp.subtract(e.getPos());
            Box b = e.getBoundingBox();

            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double cx = ((i & 1) == 0 ? b.minX : b.maxX) + off.x - cam.x;
                double cy = ((i & 2) == 0 ? b.minY : b.maxY) + off.y - cam.y;
                double cz = ((i & 4) == 0 ? b.minZ : b.maxZ) + off.z - cam.z;
                Vector4f v = new Vector4f((float) cx, (float) cy, (float) cz, 1.0f);
                v.mul(view);
                v.mul(proj);
                if (v.w <= 0.05f) {
                    ok = false;
                    break;
                }
                float sx = (v.x / v.w * 0.5f + 0.5f) * sw;
                float sy = (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh;
                minX = Math.min(minX, sx);
                maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy);
                maxY = Math.max(maxY, sy);
            }
            if (!ok) continue;
            if (maxX < -20 || minX > sw + 20 || maxY < -20 || minY > sh + 20) continue;

            float hp = MathHelper.clamp(le.getHealth() / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
            FRAMES.add(new Frame(minX, minY, maxX, maxY, hp, player));
        }
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!boxMode() || FRAMES.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        float px = 1.0f / Ui.scale();   // один физический пиксель в GUI-координатах

        for (Frame f : FRAMES) {
            float x1 = f.x1(), y1 = f.y1(), x2 = f.x2(), y2 = f.y2();
            float w = x2 - x1, h = y2 - y1;
            if (w < 4 || h < 4) continue;
            int col = f.player() ? (0xFF000000 | WorldFx.rgbOf(Config.espColor, 0.0f)) : 0xFFFFFFFF;

            if (Config.espFill) {
                Ui.rrectF(c, x1, y1, w, h, Math.min(6.0f, Math.min(w, h) / 3.0f), (col & 0xFFFFFF) | 0x14000000);
            }

            float len = Math.max(4.0f, Math.min(w, h) / 4.0f);
            float t = px * 2.0f;            // толщина линии 2 физических пикселя
            corners(c, x1, y1, x2, y2, len, 0xFF000000, t, px);   // тёмная подложка
            corners(c, x1, y1, x2, y2, len, col, t, 0.0f);

            if (Config.espHealth) {
                float bx = x1 - 4.0f;
                Ui.rect(c, bx - px, y1 - px, bx + px * 3.0f, y2 + px, 0xFF000000);
                float fill = h * f.hp();
                int hpColor = 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.75f, 1.0f);
                Ui.rect(c, bx, y2 - fill, bx + px * 2.0f, y2, hpColor);
            }
        }
    }

    /** pad > 0 рисует подложку шире линии со всех сторон. */
    private static void corners(DrawContext c, float x1, float y1, float x2, float y2,
                                float len, int color, float t, float pad) {
        float p = pad;
        // левый верх
        Ui.rect(c, x1 - p, y1 - p, x1 + len + p, y1 + t + p, color);
        Ui.rect(c, x1 - p, y1 - p, x1 + t + p, y1 + len + p, color);
        // правый верх
        Ui.rect(c, x2 - len - p, y1 - p, x2 + p, y1 + t + p, color);
        Ui.rect(c, x2 - t - p, y1 - p, x2 + p, y1 + len + p, color);
        // левый низ
        Ui.rect(c, x1 - p, y2 - t - p, x1 + len + p, y2 + p, color);
        Ui.rect(c, x1 - p, y2 - len - p, x1 + t + p, y2 + p, color);
        // правый низ
        Ui.rect(c, x2 - len - p, y2 - t - p, x2 + p, y2 + p, color);
        Ui.rect(c, x2 - t - p, y2 - len - p, x2 + p, y2 + p, color);
    }
}
