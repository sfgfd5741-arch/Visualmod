package com.visualmod.mixin;

import com.visualmod.Config;
import com.visualmod.Zoom;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** No Hurt Cam, No Bob и Zoom (FOV). Все инжекты с require = 0: если метод не найден - просто не работает, без вылета. */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "tiltViewWhenHurt(Lnet/minecraft/client/util/math/MatrixStack;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.noHurtCam) ci.cancel();
    }

    @Inject(method = "bobView(Lnet/minecraft/client/util/math/MatrixStack;F)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$noBob(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (Config.noHurtCam && Config.noBob) ci.cancel();
    }

    @Inject(method = "getFov(Lnet/minecraft/client/render/Camera;FZ)D",
            at = @At("RETURN"), cancellable = true, require = 0)
    private void visualmod$zoom(Camera camera, float tickDelta, boolean changingFov,
                                CallbackInfoReturnable<Double> cir) {
        cir.setReturnValue(Zoom.apply(cir.getReturnValueD()));
    }
}
