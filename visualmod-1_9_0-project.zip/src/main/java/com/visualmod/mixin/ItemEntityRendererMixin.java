package com.visualmod.mixin;

import com.visualmod.Config;
import com.visualmod.ItemStateExt;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Item Physics: брошенные предметы лежат на земле плашмя,
 * а в воздухе кувыркаются.
 */
@Mixin(ItemEntityRenderer.class)
public class ItemEntityRendererMixin {
    private static final String RENDER =
            "render(Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;"
                    + "Lnet/minecraft/client/util/math/MatrixStack;"
                    + "Lnet/minecraft/client/render/VertexConsumerProvider;I)V";
    private static final String UPDATE =
            "updateRenderState(Lnet/minecraft/entity/ItemEntity;"
                    + "Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V";

    private static boolean visualmod$pushed = false;
    private static boolean visualmod$ground = false;

    @Inject(method = UPDATE, at = @At("TAIL"), require = 0)
    private void visualmod$readGround(ItemEntity entity, ItemEntityRenderState state, float tickDelta,
                                      CallbackInfo ci) {
        if (state instanceof ItemStateExt ext) {
            ext.visualmod$setOnGround(entity.isOnGround());
        }
    }

    @Inject(method = RENDER, at = @At("HEAD"), require = 0)
    private void visualmod$begin(ItemEntityRenderState state, MatrixStack matrices,
                                 VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        visualmod$pushed = false;
        visualmod$ground = false;
        if (!Config.itemPhysics) return;

        boolean ground = state instanceof ItemStateExt ext && ext.visualmod$isOnGround();
        visualmod$ground = ground;
        matrices.push();
        visualmod$pushed = true;

        if (ground) {
            float yaw = Math.floorMod(System.identityHashCode(state), 360);
            matrices.translate(0.0, 0.05, 0.0);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f));
            matrices.translate(0.0, -0.35, 0.0);
        } else {
            float spin = ((System.currentTimeMillis() * Config.ipSpin) % 1800L) / 5.0f;
            matrices.translate(0.0, 0.35, 0.0);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(spin));
            matrices.translate(0.0, -0.35, 0.0);
        }
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void visualmod$end(ItemEntityRenderState state, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        if (visualmod$pushed) {
            matrices.pop();
            visualmod$pushed = false;
        }
    }

    /** Лежащий предмет не вращается вокруг оси: убираем стандартный поворот. */
    @Redirect(method = RENDER,
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ItemEntity;getRotation(FF)F"),
            require = 0)
    private float visualmod$noSpin(float age, float uniqueOffset) {
        if (visualmod$pushed && visualmod$ground) return 0.0f;
        return ItemEntity.getRotation(age, uniqueOffset);
    }
}
