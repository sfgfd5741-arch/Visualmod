package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** HUD: watermark, координаты, список модулей, клавиши, Hit Info, броня и счётчики - каждый блок можно двигать. */
public final class Hud {
    private Hud() {}

    public enum Elem { WATERMARK, INFO, MODULES, KEYS, HITINFO, ARMOR, COUNTS }

    public static final int H = 15;      // высота плашки
    private static final int ROW = 16;   // шаг строки в списке модулей
    private static final int KEY = 18, KGAP = 2, SPACE_H = 12;
    private static final int HIT_W = 126, HIT_H = 36;
    private static final int SLOT = 20;  // шаг ячейки брони
    private static final int COUNT_H = 22;
    private static final int BG = 0xB0101018;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFFA0A0B2;
    private static final int RED = 0xFFFF6B6B;
    private static final int GREEN = 0xFF69F0AE;

    private static final EquipmentSlot[] ARMOR_SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private record ModRow(String name, float v) {}

    private static final Map<String, Float> LIST_ANIM = new HashMap<>();

    // ------------------------------------------------------------ рендер

    public static void render(DrawContext c, RenderTickCounter tickCounter) {
        Anim.frame();
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;
        Screen s = mc.currentScreen;
        if (s instanceof HudEditorScreen) return;   // редактор рисует сам

        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        if (Config.hudWatermark) draw(c, mc, Elem.WATERMARK, sw, sh, false);
        if (Config.hudInfo) draw(c, mc, Elem.INFO, sw, sh, false);
        if (Config.hudModuleList) draw(c, mc, Elem.MODULES, sw, sh, false);
        if (Config.hudKeys) draw(c, mc, Elem.KEYS, sw, sh, false);
        if (Config.hitInfo && HitInfo.active()) draw(c, mc, Elem.HITINFO, sw, sh, false);
        if (Config.hudArmor) draw(c, mc, Elem.ARMOR, sw, sh, false);
        if (Config.hudCounts && !countItems().isEmpty()) draw(c, mc, Elem.COUNTS, sw, sh, false);
    }

    // ------------------------------------------------------------ геометрия

    private static int listPad() {
        return Config.mlDots ? 22 : 16;
    }

    public static int width(MinecraftClient mc, Elem e, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        switch (e) {
            case WATERMARK: {
                String rest = watermarkRest(mc);
                int w = 9 + Ui.width(tr, "VisualMod") + 9;
                if (!rest.isEmpty()) w += 8 + Ui.width(tr, rest);
                return w;
            }
            case INFO:
                return 18 + Ui.width(tr, xyz(mc));
            case KEYS:
                return KEY * 3 + KGAP * 2;
            case HITINFO:
                return HIT_W;
            case ARMOR:
                return Config.haVertical ? 24 : SLOT * 4 + 10;
            case COUNTS: {
                int cx = 8;
                for (Item it : countItems()) cx += 20 + Ui.width(tr, String.valueOf(count(mc, it, preview))) + 10;
                return cx <= 8 ? 0 : cx - 10 + 8;
            }
            default: {
                int max = 0;
                for (String m : modules(preview)) max = Math.max(max, Ui.width(tr, m) + listPad());
                return max;
            }
        }
    }

    public static int height(MinecraftClient mc, Elem e, boolean preview) {
        if (e == Elem.MODULES) {
            int n = modules(preview).size();
            return n == 0 ? 0 : n * ROW - 2;
        }
        if (e == Elem.KEYS) return KEY * 2 + KGAP * 2 + (Config.ksSpace ? SPACE_H : 0);
        if (e == Elem.HITINFO) return HIT_H;
        if (e == Elem.ARMOR) return Config.haVertical ? SLOT * 4 + 10 : 24;
        if (e == Elem.COUNTS) return COUNT_H;
        return H;
    }

    /** Левый край блока на экране с учётом границ. */
    public static int left(MinecraftClient mc, Elem e, int sw, boolean preview) {
        int w = width(mc, e, preview);
        int x = Config.hudX[e.ordinal()];
        int l = e == Elem.MODULES ? (x < 0 ? sw - 4 : x) - w : x;
        return Math.max(0, Math.min(l, Math.max(0, sw - w)));
    }

    public static int top(MinecraftClient mc, Elem e, int sh, boolean preview) {
        int h = height(mc, e, preview);
        return Math.max(0, Math.min(Config.hudY[e.ordinal()], Math.max(0, sh - h)));
    }

    public static void setPos(MinecraftClient mc, Elem e, int left, int top, boolean preview) {
        int w = width(mc, e, preview);
        Config.hudX[e.ordinal()] = e == Elem.MODULES ? left + w : left;
        Config.hudY[e.ordinal()] = top;
    }

    // ------------------------------------------------------------ содержимое

    private static String watermarkRest(MinecraftClient mc) {
        String rest = "";
        if (Config.hudFps) rest = mc.getCurrentFps() + " fps";
        if (Config.hudPing) {
            int ping = ping(mc);
            if (ping >= 0) rest += (rest.isEmpty() ? "" : "  |  ") + ping + " ms";
        }
        return rest;
    }

    private static String xyz(MinecraftClient mc) {
        if (mc.player == null) return "XYZ  0  0  0";
        String s = String.format("XYZ  %d  %d  %d",
                (int) Math.floor(mc.player.getX()),
                (int) Math.floor(mc.player.getY()),
                (int) Math.floor(mc.player.getZ()));
        if (Config.hudFacing) {
            String f = mc.player.getHorizontalFacing().asString();
            if (!f.isEmpty()) s += "  " + f.substring(0, 1).toUpperCase();
        }
        return s;
    }

    public static List<String> modules(boolean preview) {
        List<String> mods = new ArrayList<>();
        if (preview || Config.esp) mods.add("ESP");
        if (preview || Config.seeInvisibles) mods.add("SeeInvisibles");
        if (preview || Config.fullbright) mods.add("Fullbright");
        if (preview || Config.nameTags) mods.add("NameTags");
        if (preview || Config.itemPhysics) mods.add("ItemPhysics");
        if (preview || Config.jumpCircle) mods.add("JumpCircle");
        if (preview || Config.chinaHat) mods.add("ChinaHat");
        if (preview || Config.noParticles) mods.add("NoParticles");
        if (preview || Config.noHurtCam) mods.add("NoHurtCam");
        if (preview || Config.noFire) mods.add("NoFire");
        if (preview || Config.zoom) mods.add("Zoom");
        if (preview || Config.viewModel) mods.add("ViewModel");
        if (preview || Config.swingAnim) mods.add("Swing");
        if (preview || Config.hitInfo) mods.add("HitInfo");
        if (preview || Config.autoTotem) mods.add("AutoTotem");
        if (preview || Config.clickPearl) mods.add("ClickPearl");
        if (preview || Config.clickWind) mods.add("ClickWind");
        if (preview || Config.autoSprint) mods.add("AutoSprint");
        if (preview || Config.autoRespawn) mods.add("AutoRespawn");
        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer tr = mc.textRenderer;
        mods.sort(Comparator.comparingInt((String a) -> Ui.width(tr, a)).reversed());
        return mods;
    }

    /** Список с плавным появлением/исчезновением строк. */
    private static List<ModRow> animatedModules() {
        Set<String> active = new HashSet<>(modules(false));
        List<ModRow> out = new ArrayList<>();
        for (String n : modules(true)) {
            float cur = LIST_ANIM.getOrDefault(n, 0.0f);
            cur = Anim.step(cur, active.contains(n) ? 1.0f : 0.0f, 14.0f);
            LIST_ANIM.put(n, cur);
            if (cur > 0.02f) out.add(new ModRow(n, cur));
        }
        return out;
    }

    private static List<ModRow> previewModules() {
        List<ModRow> out = new ArrayList<>();
        for (String n : modules(true)) out.add(new ModRow(n, 1.0f));
        return out;
    }

    // ------------------------------------------------------------ предметы

    private static List<Item> countItems() {
        List<Item> l = new ArrayList<>();
        if (Config.ctTotem) l.add(Items.TOTEM_OF_UNDYING);
        if (Config.ctPearl) l.add(Items.ENDER_PEARL);
        if (Config.ctWind) l.add(Items.WIND_CHARGE);
        return l;
    }

    private static int count(MinecraftClient mc, Item item, boolean preview) {
        if (preview) return item == Items.TOTEM_OF_UNDYING ? 3 : item == Items.ENDER_PEARL ? 16 : 8;
        if (mc.player == null) return 0;
        PlayerInventory inv = mc.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack st = inv.getStack(i);
            if (st.isOf(item)) n += st.getCount();
        }
        return n;
    }

    private static ItemStack armorStack(MinecraftClient mc, int i, boolean preview) {
        if (preview) {
            Item[] it = {Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS};
            ItemStack st = new ItemStack(it[i]);
            st.setDamage(st.getMaxDamage() / 4 * (i + 1) / 2);
            return st;
        }
        return mc.player == null ? ItemStack.EMPTY : mc.player.getEquippedStack(ARMOR_SLOTS[i]);
    }

    // ------------------------------------------------------------ рисование блока

    public static void draw(DrawContext c, MinecraftClient mc, Elem e, int sw, int sh, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        int accent = Config.accent();
        int x = left(mc, e, sw, preview);
        int y = top(mc, e, sh, preview);
        int w = width(mc, e, preview);

        switch (e) {
            case WATERMARK: {
                Ui.capsule(c, x, y, w, H, BG);
                int tx = x + 9;
                Ui.textMid(c, tr, "VisualMod", tx, y, H, accent);
                tx += Ui.width(tr, "VisualMod");
                String rest = watermarkRest(mc);
                if (!rest.isEmpty()) Ui.textMid(c, tr, rest, tx + 8, y, H, MUTED);
                break;
            }
            case INFO: {
                Ui.capsule(c, x, y, w, H, BG);
                Ui.capsule(c, x + 6, y + (H - 5) / 2, 5, 5, accent);
                Ui.textMid(c, tr, xyz(mc), x + 15, y, H, MUTED);
                break;
            }
            case KEYS: {
                key(c, mc, "W", mc.options.forwardKey.isPressed(), x + KEY + KGAP, y, KEY, KEY, accent);
                key(c, mc, "A", mc.options.leftKey.isPressed(), x, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "S", mc.options.backKey.isPressed(), x + KEY + KGAP, y + KEY + KGAP, KEY, KEY, accent);
                key(c, mc, "D", mc.options.rightKey.isPressed(), x + (KEY + KGAP) * 2, y + KEY + KGAP, KEY, KEY, accent);
                if (Config.ksSpace) {
                    key(c, mc, "", mc.options.jumpKey.isPressed(), x, y + (KEY + KGAP) * 2, w, SPACE_H, accent);
                }
                break;
            }
            case HITINFO:
                drawHit(c, tr, x, y, w, preview, accent);
                break;
            case ARMOR:
                drawArmor(c, mc, x, y, w, height(mc, e, preview), preview);
                break;
            case COUNTS:
                drawCounts(c, mc, x, y, w, preview);
                break;
            default: {
                int right = x + w;
                float ry = y;
                int pad = listPad();
                for (ModRow r : preview ? previewModules() : animatedModules()) {
                    float ez = Anim.ease(r.v());
                    int rw = Ui.width(tr, r.name()) + pad;
                    int rh = ROW - 2;
                    float rx = right - rw + (1.0f - ez) * (rw + 6);
                    Ui.capsuleF(c, rx, ry, rw, rh, BG);
                    float tx = rx + 9;
                    if (Config.mlDots) {
                        Ui.capsuleF(c, rx + 7, ry + (rh - 4) / 2.0f, 4, 4, accent);
                        tx = rx + 15;
                    }
                    Ui.textMidF(c, tr, r.name(), tx, ry, rh, TEXT);
                    ry += ROW * ez;
                }
            }
        }
    }

    private static void drawArmor(DrawContext c, MinecraftClient mc, int x, int y, int w, int h, boolean preview) {
        boolean vert = Config.haVertical;
        Ui.rrect(c, x, y, w, h, 10, BG);
        for (int i = 0; i < 4; i++) {
            int ix = vert ? x + 4 : x + 5 + i * SLOT + 2;
            int iy = vert ? y + 5 + i * SLOT : y + 2;
            ItemStack st = armorStack(mc, i, preview);
            if (st.isEmpty()) {
                Ui.capsuleF(c, ix + 6.0f, iy + 6.0f, 4, 4, 0x40FFFFFF);
                continue;
            }
            c.drawItem(st, ix, iy);
            if (Config.haDurability && st.isDamageable()) {
                float frac = MathHelper.clamp(1.0f - (float) st.getDamage() / Math.max(1, st.getMaxDamage()), 0.0f, 1.0f);
                int col = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);
                float bx = ix + 1.0f, by = iy + 17.0f;
                Ui.rrectF(c, bx, by, 14, 2, 1, 0x80000000);
                Ui.rrectF(c, bx, by, Math.max(1.5f, 14 * frac), 2, 1, col);
            }
        }
    }

    private static void drawCounts(DrawContext c, MinecraftClient mc, int x, int y, int w, boolean preview) {
        if (w <= 0) return;
        TextRenderer tr = mc.textRenderer;
        Ui.capsule(c, x, y, w, COUNT_H, BG);
        int cx = x + 8;
        for (Item it : countItems()) {
            int n = count(mc, it, preview);
            String s = String.valueOf(n);
            c.drawItem(new ItemStack(it), cx, y + 3);
            Ui.textMid(c, tr, s, cx + 20, y, COUNT_H, n > 0 ? TEXT : MUTED);
            cx += 20 + Ui.width(tr, s) + 10;
        }
    }

    private static void drawHit(DrawContext c, TextRenderer tr, int x, int y, int w, boolean preview, int accent) {
        String name = preview ? "Player" : HitInfo.name();
        float hp = preview ? 14.0f : HitInfo.hp;
        float max = preview ? 20.0f : HitInfo.maxHp;
        float dealt = preview ? 12.5f : HitInfo.dealt;
        float healed = preview ? 4.0f : HitInfo.healed;
        float last = preview ? 3.5f : HitInfo.lastHit;

        Ui.shadow(c, x, y, w, HIT_H, 9);
        Ui.rrect(c, x, y, w, HIT_H, 9, BG);

        if (Config.hiName) Ui.textMid(c, tr, name, x + 10, y + 2, 14, accent);
        String hpText = String.format("%.1f", hp);
        Ui.textMid(c, tr, hpText, x + w - 10 - Ui.width(tr, hpText), y + 2, 14, TEXT);

        String d = "-" + String.format("%.1f", dealt);
        Ui.textMid(c, tr, d, x + 10, y + 15, 14, RED);
        if (Config.hiLast && last > 0.0f) {
            String l = "(" + String.format("%.1f", last) + ")";
            Ui.textMid(c, tr, l, x + 14 + Ui.width(tr, d), y + 15, 14, MUTED);
        }
        if (Config.hiHealed) {
            String h = "+" + String.format("%.1f", healed);
            Ui.textMid(c, tr, h, x + w - 10 - Ui.width(tr, h), y + 15, 14, GREEN);
        }

        if (Config.hiBar) {
            float frac = MathHelper.clamp(hp / Math.max(1.0f, max), 0.0f, 1.0f);
            int bw = w - 20;
            int hpColor = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);
            Ui.rrectF(c, x + 10, y + HIT_H - 6, bw, 3, 1.5f, 0x80000000);
            Ui.rrectF(c, x + 10, y + HIT_H - 6, Math.max(3.0f, bw * frac), 3, 1.5f, hpColor);
        }
    }

    private static void key(DrawContext c, MinecraftClient mc, String label, boolean down,
                            int x, int y, int w, int h, int accent) {
        Ui.rrect(c, x, y, w, h, h / 2, down ? accent : BG);
        if (label.isEmpty()) {
            Ui.capsule(c, x + w / 2 - 8, y + h / 2 - 1, 16, 2, down ? 0xFFFFFFFF : MUTED);
        } else {
            int tw = Ui.width(mc.textRenderer, label);
            Ui.textMid(c, mc.textRenderer, label, x + (w - tw) / 2, y, h, down ? 0xFFFFFFFF : MUTED);
        }
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? -1 : e.getLatency();
    }
}
