package com.noomidlc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Kill Effect: визуальный эффект в месте гибели цели.
 * Режимы: Lightning, Explosion, Souls, Shockwave, Firework.
 */
public final class KillFx {
    private KillFx() {}

    public static final String[] MODES = {"Lightning", "Explosion", "Souls", "Shockwave", "Firework"};

    private record Seen(double x, double y, double z, float h, float w) {}

    private static final class P {
        float x, y, z, vx, vy, vz, size, hue, gravity, drag;
        int life, max;
    }

    private static final class Boom {
        double x, y, z;
        int mode, life, max;
        long seed;
        float h;
    }

    private static final Map<Integer, Seen> SEEN = new HashMap<>();
    private static final Map<Integer, Integer> ENGAGED = new HashMap<>();   // id -> tick, когда мы по нему били/целились
    private static final List<P> PARTS = new ArrayList<>();
    private static final List<Boom> BOOMS = new ArrayList<>();
    private static final Random R = new Random();
    private static int tickN = 0;

    // ------------------------------------------------------------ логика

    public static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null || !Config.killFx) {
            SEEN.clear();
            ENGAGED.clear();
            PARTS.clear();
            BOOMS.clear();
            return;
        }
        tickN++;

        // запоминаем, по кому мы работаем (прицел или Kill Aura)
        HitResult hr = mc.crosshairTarget;
        if (hr instanceof EntityHitResult ehr && mc.options.attackKey.isPressed()) {
            ENGAGED.put(ehr.getEntity().getId(), tickN);
        }
        LivingEntity ka = KillAura.target();
        if (ka != null) ENGAGED.put(ka.getId(), tickN);
        if (ENGAGED.size() > 256) ENGAGED.entrySet().removeIf(e -> tickN - e.getValue() > 100);

        // кто умер с прошлого тика
        Map<Integer, Seen> now = new HashMap<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            if (!(e instanceof PlayerEntity) && !Config.kfMobs) continue;
            if (mc.player.distanceTo(e) > 48.0f) continue;
            if (le.isAlive()) {
                now.put(e.getId(), new Seen(e.getX(), e.getY(), e.getZ(), e.getHeight(), e.getWidth()));
            } else {
                Seen s = SEEN.get(e.getId());
                if (s != null) trigger(e.getId(), s);
            }
        }
        // существо исчезло совсем (вышло из мира / убито и сразу удалено)
        for (Map.Entry<Integer, Seen> en : SEEN.entrySet()) {
            if (now.containsKey(en.getKey())) continue;
            Entity still = mc.world.getEntityById(en.getKey());
            if (still == null && en.getValue() != null) {
                // мог просто выйти из прорисовки - считаем убийством только если рядом и недавно с ним дрались
                double d = mc.player.squaredDistanceTo(en.getValue().x(), en.getValue().y(), en.getValue().z());
                if (d < 40.0 * 40.0 && ENGAGED.containsKey(en.getKey()) && tickN - ENGAGED.get(en.getKey()) < 20) {
                    trigger(en.getKey(), en.getValue());
                }
            }
        }
        SEEN.clear();
        SEEN.putAll(now);

        // анимации
        Iterator<P> it = PARTS.iterator();
        while (it.hasNext()) {
            P q = it.next();
            q.x += q.vx;
            q.y += q.vy;
            q.z += q.vz;
            q.vx *= q.drag;
            q.vy = q.vy * q.drag - q.gravity;
            q.vz *= q.drag;
            if (++q.life >= q.max) it.remove();
        }
        BOOMS.removeIf(b -> ++b.life >= b.max);
    }

    private static void trigger(int id, Seen s) {
        if (Config.kfMine) {
            Integer t = ENGAGED.get(id);
            if (t == null || tickN - t > 60) return;
        }
        int mode = Math.floorMod(Config.kfMode, MODES.length);
        Boom b = new Boom();
        b.x = s.x();
        b.y = s.y();
        b.z = s.z();
        b.h = s.h();
        b.mode = mode;
        b.seed = R.nextLong();
        b.life = 0;
        b.max = switch (mode) {
            case 0 -> 12;
            case 3 -> 26;
            default -> 18;
        };
        BOOMS.add(b);

        int cnt = Math.max(6, Math.round(28 * Config.kfAmount));
        double cy = s.y() + s.h() * 0.5;
        switch (mode) {
            case 1 -> {   // взрыв искр
                for (int i = 0; i < cnt * 2; i++) {
                    P q = part(s.x(), cy, s.z(), 18 + R.nextInt(14), 0.08f + R.nextFloat() * 0.07f);
                    double a = R.nextDouble() * Math.PI * 2.0;
                    double up = R.nextDouble() * 2.0 - 1.0;
                    double sp = 0.1 + R.nextDouble() * 0.28;
                    double flat = Math.sqrt(Math.max(0.0, 1.0 - up * up));
                    q.vx = (float) (Math.cos(a) * sp * flat);
                    q.vz = (float) (Math.sin(a) * sp * flat);
                    q.vy = (float) (up * sp);
                    q.gravity = 0.006f;
                    q.drag = 0.9f;
                }
            }
            case 2 -> {   // души поднимаются вверх спиралью
                for (int i = 0; i < cnt; i++) {
                    P q = part(s.x() + (R.nextDouble() - 0.5) * s.w(), s.y() + R.nextDouble() * s.h(),
                            s.z() + (R.nextDouble() - 0.5) * s.w(), 26 + R.nextInt(18), 0.1f + R.nextFloat() * 0.06f);
                    q.vx = (R.nextFloat() - 0.5f) * 0.02f;
                    q.vz = (R.nextFloat() - 0.5f) * 0.02f;
                    q.vy = 0.05f + R.nextFloat() * 0.07f;
                    q.drag = 0.97f;
                }
            }
            case 4 -> {   // фейерверк: шар из частиц
                for (int i = 0; i < cnt * 2; i++) {
                    P q = part(s.x(), cy + s.h() * 0.4, s.z(), 26 + R.nextInt(10), 0.09f);
                    double a = R.nextDouble() * Math.PI * 2.0;
                    double b2 = Math.acos(2.0 * R.nextDouble() - 1.0);
                    double sp = 0.2 + R.nextDouble() * 0.04;
                    q.vx = (float) (Math.sin(b2) * Math.cos(a) * sp);
                    q.vy = (float) (Math.cos(b2) * sp);
                    q.vz = (float) (Math.sin(b2) * Math.sin(a) * sp);
                    q.gravity = 0.005f;
                    q.drag = 0.88f;
                }
            }
            default -> {   // молния - небольшая вспышка искр у земли
                for (int i = 0; i < cnt / 2; i++) {
                    P q = part(s.x(), s.y() + 0.1, s.z(), 12 + R.nextInt(8), 0.07f);
                    double a = R.nextDouble() * Math.PI * 2.0;
                    double sp = 0.05 + R.nextDouble() * 0.12;
                    q.vx = (float) (Math.cos(a) * sp);
                    q.vz = (float) (Math.sin(a) * sp);
                    q.vy = 0.03f + R.nextFloat() * 0.1f;
                    q.gravity = 0.006f;
                    q.drag = 0.9f;
                }
            }
        }
    }

    private static P part(double x, double y, double z, int max, float size) {
        P q = new P();
        q.x = (float) x;
        q.y = (float) y;
        q.z = (float) z;
        q.max = max;
        q.size = size * Config.kfSize;
        q.hue = R.nextFloat();
        q.drag = 0.93f;
        PARTS.add(q);
        return q;
    }

    // ------------------------------------------------------------ рендер

    public static void render(WorldRenderContext ctx) {
        if (!Config.killFx || (PARTS.isEmpty() && BOOMS.isEmpty())) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Vec3d cam = ctx.camera().getPos();
        float td = ctx.tickCounter().getTickDelta(true);
        Quaternionf rot = ctx.camera().getRotation();
        Vector3f right = new Vector3f(1.0f, 0.0f, 0.0f).rotate(rot);
        Vector3f up = new Vector3f(0.0f, 1.0f, 0.0f).rotate(rot);

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = ms.peek().getPositionMatrix();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(com.mojang.blaze3d.platform.GlStateManager.SrcFactor.SRC_ALPHA,
                com.mojang.blaze3d.platform.GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        // частицы
        if (!PARTS.isEmpty()) {
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            for (P q : PARTS) {
                float f = (q.life + td) / q.max;
                float fade = (float) Math.pow(1.0f - Math.min(1.0f, f), 1.3);
                float x = q.x + q.vx * td, y = q.y + q.vy * td, z = q.z + q.vz * td;
                int rgb = WorldFx.rgbOf(Config.kfColor, q.hue);
                quad(b, mat, x, y, z, right, up, q.size * 2.6f * (0.6f + 0.4f * fade), rgb, fade * 0.22f);
                quad(b, mat, x, y, z, right, up, q.size * (0.5f + 0.5f * fade), rgb, Math.min(1.0f, fade * 1.1f));
            }
            Ui.flush(b);
        }

        // молнии и кольца
        for (Boom bm : BOOMS) {
            float f = (bm.life + td) / bm.max;
            float fade = 1.0f - Math.min(1.0f, f);
            if (bm.mode == 0) lightning(mat, bm, fade, right);
            else if (bm.mode == 3 || bm.mode == 1) shock(mat, bm, f, fade);
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    /** Зубчатая молния, бьющая вниз с неба в точку гибели. */
    private static void lightning(Matrix4f mat, Boom bm, float fade, Vector3f right) {
        Random r = new Random(bm.seed);
        int segs = 14;
        float topY = (float) bm.y + 24.0f;
        float[] xs = new float[segs + 1], zs = new float[segs + 1], ys = new float[segs + 1];
        for (int i = 0; i <= segs; i++) {
            float t = i / (float) segs;
            ys[i] = topY + ((float) bm.y - topY) * t;
            float jitter = (i == 0 || i == segs) ? 0.0f : 1.0f;
            xs[i] = (float) bm.x + (r.nextFloat() - 0.5f) * 1.6f * jitter * (1.0f - t * 0.4f);
            zs[i] = (float) bm.z + (r.nextFloat() - 0.5f) * 1.6f * jitter * (1.0f - t * 0.4f);
        }
        int rgb = WorldFx.rgbOf(Config.kfColor, 0.0f);
        for (int layer = 0; layer < 3; layer++) {
            float w = switch (layer) { case 0 -> 0.42f; case 1 -> 0.2f; default -> 0.07f; } * Config.kfSize;
            float a = switch (layer) { case 0 -> 0.18f; case 1 -> 0.4f; default -> 1.0f; } * fade;
            int col = ((Math.round(Math.min(1.0f, a) * 255.0f)) << 24) | ((layer == 2 ? 0xFFFFFF : rgb) & 0xFFFFFF);
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= segs; i++) {
                b.vertex(mat, xs[i] - right.x * w, ys[i] - right.y * w, zs[i] - right.z * w).color(col);
                b.vertex(mat, xs[i] + right.x * w, ys[i] + right.y * w, zs[i] + right.z * w).color(col);
            }
            Ui.flush(b);
        }
    }

    /** Расширяющееся горизонтальное кольцо (ударная волна). */
    private static void shock(Matrix4f mat, Boom bm, float f, float fade) {
        float r = (0.4f + f * 4.5f) * Config.kfSize;
        float w = 0.12f + 0.15f * fade;
        int segs = 48;
        int rgb = WorldFx.rgbOf(Config.kfColor, 0.0f);
        for (int ring = 0; ring < (bm.mode == 3 ? 2 : 1); ring++) {
            float rr = r * (1.0f - ring * 0.45f);
            if (rr <= 0.0f) continue;
            BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= segs; i++) {
                double a = i / (double) segs * Math.PI * 2.0;
                float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
                int col = (Math.round(Math.min(1.0f, fade * (ring == 0 ? 0.9f : 0.5f)) * 255.0f) << 24)
                        | (WorldFx.rgbOf(Config.kfColor, i / (float) segs) & 0xFFFFFF);
                float y = (float) bm.y + 0.05f + ring * 0.03f;
                b.vertex(mat, (float) bm.x + cs * (rr - w), y, (float) bm.z + sn * (rr - w)).color(col);
                b.vertex(mat, (float) bm.x + cs * (rr + w), y, (float) bm.z + sn * (rr + w)).color(col);
            }
            Ui.flush(b);
        }
    }

    private static void quad(BufferBuilder b, Matrix4f m, float x, float y, float z,
                             Vector3f r, Vector3f u, float s, int rgb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
        int col = (a << 24) | (rgb & 0xFFFFFF);
        b.vertex(m, x + (-r.x - u.x) * s, y + (-r.y - u.y) * s, z + (-r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x - u.x) * s, y + (r.y - u.y) * s, z + (r.z - u.z) * s).color(col);
        b.vertex(m, x + (r.x + u.x) * s, y + (r.y + u.y) * s, z + (r.z + u.z) * s).color(col);
        b.vertex(m, x + (-r.x + u.x) * s, y + (-r.y + u.y) * s, z + (-r.z + u.z) * s).color(col);
    }
}
