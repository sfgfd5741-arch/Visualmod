package com.noomidlc.mixin;

import com.noomidlc.Config;
import com.noomidlc.Ui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.LogoDrawer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Главный экран: вместо логотипа Minecraft рисуем "noomidlc". */
@Mixin(LogoDrawer.class)
public abstract class LogoDrawerMixin {
    @Inject(method = "draw(Lnet/minecraft/client/gui/DrawContext;IF)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$logo3(DrawContext c, int width, float alpha, CallbackInfo ci) {
        if (Config.customTitle) {
            noomidlc$paint(c, width, alpha, 30);
            ci.cancel();
        }
    }

    @Inject(method = "draw(Lnet/minecraft/client/gui/DrawContext;IFI)V", at = @At("HEAD"), cancellable = true, require = 0)
    private void noomidlc$logo4(DrawContext c, int width, float alpha, int y, CallbackInfo ci) {
        if (Config.customTitle) {
            noomidlc$paint(c, width, alpha, y);
            ci.cancel();
        }
    }

    private static void noomidlc$paint(DrawContext c, int width, float alpha, int y) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String text = "noomidlc";
        float scale = 3.2f;
        long t = System.currentTimeMillis();
        int w = Ui.width(mc.textRenderer, text);
        float cx = width / 2.0f;
        c.getMatrices().push();
        c.getMatrices().translate(cx, y + 6, 0.0f);
        c.getMatrices().scale(scale, scale, 1.0f);
        // мягкое свечение: смещённые копии с малой прозрачностью
        int acc = Config.accent() & 0xFFFFFF;
        for (int i = 3; i >= 1; i--) {
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f - i * 0.4f, 0, Ui.alpha(acc, 0.10f * alpha));
            Ui.textF(c, mc.textRenderer, text, -w / 2.0f + i * 0.4f, 0, Ui.alpha(acc, 0.10f * alpha));
        }
        float pulse = 0.85f + 0.15f * (float) Math.sin(t / 500.0);
        Ui.textF(c, mc.textRenderer, text, -w / 2.0f, 0, Ui.alpha(0xFFFFFF, alpha * pulse));
        c.getMatrices().pop();
        // подчёркивание-градиент
        float lw = w * scale;
        Ui.rect(c, cx - lw / 2.0f, y + 6 + 11 * scale, cx + lw / 2.0f, y + 6 + 11 * scale + 1.5f, Ui.alpha(acc, 0.9f * alpha));
    }
}
