package com.noomidlc;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConnectScreen;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Дополнительные модули 3.2.0: Auto Tool, Auto Eat, Auto Walk, Weather Changer, Trails, Death Coords,
 * Inventory Sorter, Auto Reconnect, Notifications, Chat Timestamps и Info Panel.
 */
public final class NewMods {
    private NewMods() {}

    private static final long SESSION_START = System.currentTimeMillis();

    // ------------------------------------------------------------ общие данные
    private static double lastX, lastZ;
    private static boolean haveLast = false;
    private static float speed = 0.0f;   // блоков в секунду

    public static void tick(MinecraftClient mc) {
        Noomidlc.safe("nm.speed", () -> tickSpeed(mc));
        Noomidlc.safe("autotool", () -> tickAutoTool(mc));
        Noomidlc.safe("autoeat", () -> tickAutoEat(mc));
        Noomidlc.safe("autowalk", () -> tickAutoWalk(mc));
        Noomidlc.safe("weather", () -> tickWeather(mc));
        Noomidlc.safe("trails", () -> tickTrails(mc));
        Noomidlc.safe("deathcoords", () -> tickDeath(mc));
        Noomidlc.safe("invsort", () -> tickSort(mc));
        Noomidlc.safe("reconnect", () -> tickReconnect(mc));
        Noomidlc.safe("notify.tick", () -> tickNotify());
    }

    private static void tickSpeed(MinecraftClient mc) {
        if (mc.player == null) {
            haveLast = false;
            speed = 0.0f;
            return;
        }
        double x = mc.player.getX(), z = mc.player.getZ();
        if (haveLast) {
            double d = Math.hypot(x - lastX, z - lastZ) * 20.0;
            speed += ((float) d - speed) * 0.25f;
        }
        lastX = x;
        lastZ = z;
        haveLast = true;
    }

    // ------------------------------------------------------------ Auto Tool
    private static int toolPrev = -1;

    private static void tickAutoTool(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) {
            toolPrev = -1;
            return;
        }
        PlayerInventory inv = mc.player.getInventory();
        BlockHitResult bhr = null;
        if (mc.crosshairTarget instanceof BlockHitResult b && b.getType() == HitResult.Type.BLOCK) bhr = b;

        boolean mining = Config.autoTool && mc.currentScreen == null && bhr != null
                && mc.options.attackKey.isPressed() && !mc.player.isUsingItem() && !eating;
        if (mining) {
            BlockState st = mc.world.getBlockState(bhr.getBlockPos());
            float best = inv.getStack(inv.selectedSlot).getMiningSpeedMultiplier(st);
            int slot = -1;
            for (int i = 0; i < 9; i++) {
                float sp = inv.getStack(i).getMiningSpeedMultiplier(st);
                if (sp > best + 0.01f) {
                    best = sp;
                    slot = i;
                }
            }
            if (slot >= 0) {
                if (toolPrev < 0) toolPrev = inv.selectedSlot;
                inv.selectedSlot = slot;
            }
        } else if (toolPrev >= 0) {
            if (Config.atRestore) inv.selectedSlot = toolPrev;
            toolPrev = -1;
        }
    }

    // ------------------------------------------------------------ Auto Eat
    private static boolean eating = false;
    private static int eatPrev = -1;
    private static final Set<Item> BAD_FOOD = new HashSet<>();

    static {
        BAD_FOOD.add(Items.ROTTEN_FLESH);
        BAD_FOOD.add(Items.SPIDER_EYE);
        BAD_FOOD.add(Items.POISONOUS_POTATO);
        BAD_FOOD.add(Items.PUFFERFISH);
        BAD_FOOD.add(Items.CHORUS_FRUIT);
        BAD_FOOD.add(Items.SUSPICIOUS_STEW);
        BAD_FOOD.add(Items.GOLDEN_APPLE);
        BAD_FOOD.add(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static boolean isFood(ItemStack s) {
        return s != null && !s.isEmpty() && s.get(DataComponentTypes.FOOD) != null && !BAD_FOOD.contains(s.getItem());
    }

    private static void stopEating(MinecraftClient mc) {
        mc.options.useKey.setPressed(false);
        if (mc.player != null && eatPrev >= 0) mc.player.getInventory().selectedSlot = eatPrev;
        eatPrev = -1;
        eating = false;
    }

    private static void tickAutoEat(MinecraftClient mc) {
        if (mc.player == null) {
            eating = false;
            eatPrev = -1;
            return;
        }
        if (!Config.autoEat) {
            if (eating) stopEating(mc);
            return;
        }
        int food = mc.player.getHungerManager().getFoodLevel();
        if (eating) {
            boolean handFood = isFood(mc.player.getMainHandStack()) || isFood(mc.player.getOffHandStack());
            if (food >= 20 || !handFood || mc.player.isDead() || mc.currentScreen != null) stopEating(mc);
            else mc.options.useKey.setPressed(true);
            return;
        }
        if (mc.currentScreen != null || mc.player.isDead()) return;
        if (food > Config.aeHunger || !mc.player.canConsume(false)) return;
        PlayerInventory inv = mc.player.getInventory();
        if (isFood(mc.player.getOffHandStack())) {
            eating = true;
            mc.options.useKey.setPressed(true);
            return;
        }
        for (int i = 0; i < 9; i++) {
            if (isFood(inv.getStack(i))) {
                eatPrev = inv.selectedSlot;
                inv.selectedSlot = i;
                eating = true;
                mc.options.useKey.setPressed(true);
                return;
            }
        }
    }

    // ------------------------------------------------------------ Auto Walk
    private static boolean walkApplied = false;

    private static void tickAutoWalk(MinecraftClient mc) {
        if (mc.player == null) {
            walkApplied = false;
            return;
        }
        if (Config.autoWalk && mc.currentScreen == null) {
            mc.options.forwardKey.setPressed(true);
            walkApplied = true;
        } else if (walkApplied) {
            mc.options.forwardKey.setPressed(false);
            walkApplied = false;
        }
    }

    // ------------------------------------------------------------ Weather Changer
    private static void tickWeather(MinecraftClient mc) {
        if (!Config.noWeather || mc.world == null) return;
        mc.world.setRainGradient(0.0f);
        mc.world.setThunderGradient(0.0f);
    }

    // ------------------------------------------------------------ Trails
    public static final String[] TRAIL_MODES = {"End Rod", "Flame", "Soul Fire", "Hearts", "Notes", "Enchant", "Electric", "Cloud"};

    private static ParticleEffect trailEffect() {
        switch (Math.floorMod(Config.trMode, TRAIL_MODES.length)) {
            case 1: return ParticleTypes.FLAME;
            case 2: return ParticleTypes.SOUL_FIRE_FLAME;
            case 3: return ParticleTypes.HEART;
            case 4: return ParticleTypes.NOTE;
            case 5: return ParticleTypes.ENCHANT;
            case 6: return ParticleTypes.ELECTRIC_SPARK;
            case 7: return ParticleTypes.CLOUD;
            default: return ParticleTypes.END_ROD;
        }
    }

    private static void tickTrails(MinecraftClient mc) {
        if (!Config.trails || mc.player == null || mc.world == null) return;
        if (speed < 0.5f && !(mc.player.getVelocity().lengthSquared() > 0.003)) return;
        ParticleEffect e = trailEffect();
        int n = Math.max(1, Math.round(Config.trAmount));
        for (int i = 0; i < n; i++) {
            double ox = (Math.random() - 0.5) * 0.4;
            double oz = (Math.random() - 0.5) * 0.4;
            double oy = 0.05 + Math.random() * 0.2;
            mc.world.addParticle(e, mc.player.getX() + ox, mc.player.getY() + oy, mc.player.getZ() + oz, 0.0, 0.01, 0.0);
        }
    }

    // ------------------------------------------------------------ Death Coords
    private static boolean deadFlag = false;

    private static void tickDeath(MinecraftClient mc) {
        if (mc.player == null) {
            deadFlag = false;
            return;
        }
        if (mc.player.isDead() || mc.player.getHealth() <= 0.0f) {
            if (!deadFlag && Config.deathCoords) {
                deadFlag = true;
                String dim = mc.world == null ? "?" : mc.world.getRegistryKey().getValue().getPath();
                mc.player.sendMessage(Text.literal("[noomidlc] Ты умер: X " + Math.round(mc.player.getX())
                        + "  Y " + Math.round(mc.player.getY()) + "  Z " + Math.round(mc.player.getZ())
                        + "  (" + dim + ")").formatted(Formatting.RED), false);
            }
        } else {
            deadFlag = false;
        }
    }

    // ------------------------------------------------------------ Inventory Sorter
    private static final ArrayDeque<int[]> SORT_QUEUE = new ArrayDeque<>();
    private static boolean sortKeyWas = false;

    private static String keyOf(ItemStack s) {
        return s.isEmpty() ? "~" : s.getItem().toString();
    }

    private static void planSort(MinecraftClient mc) {
        List<String> cur = new ArrayList<>();
        for (int i = 9; i < 36; i++) cur.add(keyOf(mc.player.playerScreenHandler.getSlot(i).getStack()));
        List<String> target = new ArrayList<>(cur);
        java.util.Collections.sort(target);
        SORT_QUEUE.clear();
        for (int i = 0; i < cur.size(); i++) {
            if (cur.get(i).equals(target.get(i))) continue;
            for (int j = i + 1; j < cur.size(); j++) {
                if (cur.get(j).equals(target.get(i))) {
                    SORT_QUEUE.add(new int[]{9 + i, 9 + j});
                    String t = cur.get(i);
                    cur.set(i, cur.get(j));
                    cur.set(j, t);
                    break;
                }
            }
        }
    }

    private static void tickSort(MinecraftClient mc) {
        if (!Config.invSort || mc.player == null || mc.interactionManager == null) {
            SORT_QUEUE.clear();
            return;
        }
        boolean inInv = mc.currentScreen instanceof InventoryScreen;
        if (!inInv) {
            SORT_QUEUE.clear();
            sortKeyWas = false;
            return;
        }
        boolean down = Config.sortBind != -1 && Actions.isDown(mc, Config.sortBind);
        if (down && !sortKeyWas && SORT_QUEUE.isEmpty()) planSort(mc);
        sortKeyWas = down;

        if (!SORT_QUEUE.isEmpty() && mc.player.playerScreenHandler.getCursorStack().isEmpty()) {
            int[] sw = SORT_QUEUE.poll();
            int sync = mc.player.playerScreenHandler.syncId;
            mc.interactionManager.clickSlot(sync, sw[0], 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(sync, sw[1], 0, SlotActionType.PICKUP, mc.player);
            mc.interactionManager.clickSlot(sync, sw[0], 0, SlotActionType.PICKUP, mc.player);
        }
    }

    // ------------------------------------------------------------ Auto Reconnect
    private static ServerInfo lastServer = null;
    private static long reconnectStart = -1L;

    private static void tickReconnect(MinecraftClient mc) {
        ServerInfo cur = mc.getCurrentServerEntry();
        if (cur != null) lastServer = cur;
        if (!Config.autoReconnect || lastServer == null || !(mc.currentScreen instanceof DisconnectedScreen)) {
            reconnectStart = -1L;
            return;
        }
        long now = System.currentTimeMillis();
        if (reconnectStart < 0L) reconnectStart = now;
        if (now - reconnectStart >= (long) (Config.reconSec * 1000.0f)) {
            reconnectStart = -1L;
            ServerInfo info = lastServer;
            ConnectScreen.connect(new TitleScreen(), mc, ServerAddress.parse(info.address), info, false, null);
        }
    }

    /** Подпись обратного отсчёта на экране отключения. */
    public static void drawReconnect(MinecraftClient mc, DrawContext ctx, int sw, int sh) {
        if (!Config.autoReconnect || lastServer == null || reconnectStart < 0L) return;
        float left = Config.reconSec - (System.currentTimeMillis() - reconnectStart) / 1000.0f;
        String s = String.format(Locale.ROOT, "Auto Reconnect: %.1f c", Math.max(0.0f, left));
        ctx.drawCenteredTextWithShadow(mc.textRenderer, s, sw / 2, sh - 40, 0xFFFFFFFF);
    }

    // ------------------------------------------------------------ Chat Timestamps
    public static Text stamp(Text message, boolean overlay) {
        if (!Config.chatTime || overlay) return message;
        String t = LocalTime.now().format(DateTimeFormatter.ofPattern(Config.chatTime24 ? "HH:mm" : "hh:mm a", Locale.ROOT));
        return Text.literal("[" + t + "] ").formatted(Formatting.GRAY).append(message);
    }

    // ------------------------------------------------------------ Notifications
    private static final class Toast {
        final String text;
        final boolean on;
        final long born;

        Toast(String text, boolean on, long born) {
            this.text = text;
            this.on = on;
            this.born = born;
        }
    }

    private static final Map<String, Boolean> PREV = new HashMap<>();
    private static final List<Toast> TOASTS = new ArrayList<>();

    private static void tickNotify() {
        long now = System.currentTimeMillis();
        for (Modules.Mod m : Modules.all()) {
            boolean v = m.get().getAsBoolean();
            Boolean old = PREV.put(m.id(), v);
            if (old != null && old != v && Config.notify) {
                TOASTS.add(new Toast(m.label(), v, now));
                if (TOASTS.size() > 6) TOASTS.remove(0);
            }
        }
        TOASTS.removeIf(t -> now - t.born > 2400L);
    }

    public static void drawNotify(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.notify || mc.player == null || mc.options.hudHidden || TOASTS.isEmpty()) return;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int accent = Config.accent();
        long now = System.currentTimeMillis();
        int idx = 0;
        for (int i = TOASTS.size() - 1; i >= 0; i--) {
            Toast t = TOASTS.get(i);
            long age = now - t.born;
            float in = Math.min(1.0f, age / 180.0f);
            float out = Math.min(1.0f, (2400L - age) / 300.0f);
            float a = Math.max(0.0f, Math.min(in, out));
            String label = t.text + (t.on ? "  ON" : "  OFF");
            int w = mc.textRenderer.getWidth(label) + 20;
            int x = (sw - w) / 2;
            int y = sh - 76 - idx * 22 + Math.round((1.0f - in) * 8.0f);
            int alpha = Math.max(8, Math.round(a * 200.0f));
            ctx.fill(x, y, x + w, y + 17, (alpha << 24) | 0x101018);
            ctx.fill(x, y + 16, x + w, y + 17, (Math.max(8, Math.round(a * 255.0f)) << 24) | (t.on ? 0x55DD88 : 0xFF5555));
            int ta = Math.max(8, Math.round(a * 255.0f));
            ctx.drawText(mc.textRenderer, label, x + 10, y + 5, (ta << 24) | (t.on ? 0xFFFFFF : 0xD8D8E8), true);
            idx++;
        }
    }

    // ------------------------------------------------------------ Info Panel (правый нижний угол)
    public static void drawInfo(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Config.infoPanel || mc.player == null || mc.world == null || mc.options.hudHidden) return;
        List<String> lines = new ArrayList<>();
        if (Config.ipSpeed) lines.add(String.format(Locale.ROOT, "Speed   %.2f b/s", speed));
        if (Config.ipBiome) {
            String b = mc.world.getBiome(mc.player.getBlockPos()).getKey()
                    .map(k -> k.getValue().getPath()).orElse("?").replace('_', ' ');
            lines.add("Biome   " + b);
        }
        if (Config.ipLight) lines.add("Light   " + mc.world.getLightLevel(mc.player.getBlockPos()));
        if (Config.ipDay) lines.add("Day     " + (mc.world.getTimeOfDay() / 24000L));
        if (Config.ipSession) {
            long s = (System.currentTimeMillis() - SESSION_START) / 1000L;
            lines.add(String.format(Locale.ROOT, "Session %d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60));
        }
        if (Config.ipMemory) {
            Runtime rt = Runtime.getRuntime();
            long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
            lines.add("Memory  " + used + " / " + (rt.maxMemory() / 1048576L) + " MB");
        }
        if (Config.ipServer) {
            ServerInfo si = mc.getCurrentServerEntry();
            String s = si != null ? si.address : (mc.isInSingleplayer() ? "Singleplayer" : "-");
            int online = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerList().size() : 0;
            lines.add("Server  " + s + "  (" + online + ")");
        }
        if (lines.isEmpty()) return;

        int w = 0;
        for (String l : lines) w = Math.max(w, mc.textRenderer.getWidth(l));
        w += 14;
        int h = lines.size() * 11 + 7;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        int x = sw - w - 8;
        int y = sh - h - 8;
        int accent = Config.accent();
        ctx.fill(x, y, x + w, y + h, 0xB9101018);
        ctx.fill(x, y, x + w, y + 1, accent);
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawText(mc.textRenderer, lines.get(i), x + 7, y + 5 + i * 11, 0xFFE8E8F0, true);
        }
    }
}
