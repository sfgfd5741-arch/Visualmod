# VisualMod (Fabric 1.21.4)

Меню: **Right Shift** (открыть/закрыть). Окно можно двигать за пустое место. Настройки: `config/visualmod.properties`.

Вкладки:
- **Visuals:** ESP (режимы Box / Glow, мобы), See invisibles, NameTags, Fullbright, Item Physics
- **Viewmodel:** положение (X/Y/Z) и размер предмета в руке
- **Animation:** Swing Animation, стиль (Vanilla / Sideways / Push), скорость, наклон
- **HUD:** watermark, координаты, список модулей, **Keystrokes (WASD)**, шрифт (Vanilla / JetBrains / Geist / Carlito), цвет, кнопка **Move HUD**
- **Misc:** **Auto Sprint**, сброс позиций HUD

Шрифты: JetBrains Mono, Geist Mono, Carlito (все SIL OFL 1.1, лицензии в `assets/visualmod/font/`).

## Сборка
Нужна Java 21.

    gradlew build        (Windows)
    ./gradlew build      (Linux/macOS)

Мод: `build/libs/visualmod-1.0.0.jar` (не `-sources`). Кладите в `mods` вместе с Fabric API 0.119.2+1.21.4.
