# VisualMod (Fabric 1.21.4)

Меню: **Right Shift** (открыть/закрыть).

Функции:
- ESP: обводка живых существ (ванильный glow)
- Fullbright: полная яркость
- ViewModel: положение (X/Y/Z) и размер предмета в руке
- HUD: название и список включённых модулей

## Сборка
Нужна Java 21.

    gradlew build        (Windows)
    ./gradlew build      (Linux/macOS)

Готовый мод: `build/libs/visualmod-1.0.0.jar` (не `-sources`). Кладите в папку `mods` вместе с Fabric API 0.119.2+1.21.4.

Если в папке нет `gradlew`, выполните один раз `gradle wrapper` (нужен установленный Gradle) или откройте проект в IntelliJ IDEA и запустите задачу `build`.

Клавишу можно сменить в Настройки - Управление - VisualMod.
