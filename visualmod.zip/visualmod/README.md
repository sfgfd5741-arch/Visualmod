# VisualMod (Fabric 1.21.4)

Меню: **Right Shift** (открыть/закрыть). Настройки сохраняются в `config/visualmod.properties`.

Вкладки меню:
- **Visuals:** ESP, Fullbright, NameTags (ник, здоровье, дистанция), Item Physics
- **Viewmodel:** положение (X/Y/Z) и размер предмета в руке, кнопка Reset
- **Animation:** Swing Animation (скорость и наклон взмаха)
- **HUD:** плашка с названием/FPS/пингом, координаты, список модулей, цвет темы

## Сборка
Нужна Java 21.

    gradlew build        (Windows)
    ./gradlew build      (Linux/macOS)

Готовый мод: `build/libs/visualmod-1.0.0.jar` (не `-sources`). Кладите в папку `mods` вместе с Fabric API 0.119.2+1.21.4.

Клавишу можно сменить в Настройки - Управление - VisualMod.
