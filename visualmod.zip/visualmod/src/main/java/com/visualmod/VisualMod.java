package com.visualmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

public class VisualMod implements ClientModInitializer {
    public static KeyBinding menuKey;
    private static boolean fullbrightApplied = false;

    @Override
    public void onInitializeClient() {
        Config.load();

        // Меню открывается на Right Shift
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.visualmod.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.visualmod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClickGuiScreen());
                }
            }
            tickFullbright(client);
        });

        WorldRenderEvents.LAST.register(NameTags::collect);
        HudRenderCallback.EVENT.register(NameTags::draw);
        HudRenderCallback.EVENT.register(Hud::render);
    }

    /** Fullbright через клиентский эффект ночного зрения (на сервер ничего не отправляется). */
    private static void tickFullbright(MinecraftClient client) {
        if (client.player == null) {
            fullbrightApplied = false;
            return;
        }
        if (Config.fullbright) {
            StatusEffectInstance cur = client.player.getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur == null || cur.getDuration() < 400) {
                client.player.addStatusEffect(
                        new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1000, 0, false, false, false));
            }
            fullbrightApplied = true;
        } else if (fullbrightApplied) {
            client.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            fullbrightApplied = false;
        }
    }
}
