package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

/** Ровный HUD: плашка с названием/FPS/пингом, координаты и список модулей справа. */
public final class Hud {
    private Hud() {}

    private static final int BG = 0xA0101018;
    private static final int TEXT = 0xFFE8E8F0;
    private static final int MUTED = 0xFF9A9AAA;
    private static final int H = 14;

    public static void render(DrawContext c, RenderTickCounter tickCounter) {
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.player == null) return;

        TextRenderer tr = mc.textRenderer;
        int accent = Config.accent();

        // --- слева сверху ---
        int x = 4;
        int y = 4;

        if (Config.hudWatermark) {
            String name = "VisualMod";
            String rest = "";
            if (Config.hudInfo) {
                rest = mc.getCurrentFps() + " fps";
                int ping = ping(mc);
                if (ping >= 0) rest += "  |  " + ping + " ms";
            }
            int nameW = tr.getWidth(name);
            int w = 6 + nameW + 6 + (rest.isEmpty() ? 0 : 6 + tr.getWidth(rest) + 0);
            c.fill(x, y, x + w, y + H, BG);
            c.fill(x, y, x + w, y + 1, accent);
            c.drawText(tr, name, x + 6, y + 4, accent, true);
            if (!rest.isEmpty()) {
                c.drawText(tr, rest, x + 6 + nameW + 6, y + 4, TEXT, true);
            }
            y += H + 2;
        }

        if (Config.hudInfo) {
            String xyz = String.format("XYZ  %d  %d  %d",
                    (int) Math.floor(mc.player.getX()),
                    (int) Math.floor(mc.player.getY()),
                    (int) Math.floor(mc.player.getZ()));
            int w = 12 + tr.getWidth(xyz);
            c.fill(x, y, x + w, y + H, BG);
            c.fill(x, y, x + 2, y + H, accent);
            c.drawText(tr, xyz, x + 7, y + 4, MUTED, true);
        }

        // --- справа сверху: список включённых модулей ---
        if (Config.hudModuleList) {
            List<String> mods = new ArrayList<>();
            if (Config.esp) mods.add("ESP");
            if (Config.fullbright) mods.add("Fullbright");
            if (Config.nameTags) mods.add("NameTags");
            if (Config.itemPhysics) mods.add("ItemPhysics");
            if (Config.viewModel) mods.add("ViewModel");
            if (Config.swingAnim) mods.add("Swing");
            mods.sort((a, b) -> tr.getWidth(b) - tr.getWidth(a));

            int right = mc.getWindow().getScaledWidth() - 4;
            int ry = 4;
            for (String s : mods) {
                int w = tr.getWidth(s) + 12;
                c.fill(right - w, ry, right, ry + H - 1, BG);
                c.fill(right - 2, ry, right, ry + H - 1, accent);
                c.drawText(tr, s, right - w + 5, ry + 3, TEXT, true);
                ry += H;
            }
        }
    }

    private static int ping(MinecraftClient mc) {
        if (mc.getNetworkHandler() == null || mc.player == null) return -1;
        PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return e == null ? -1 : e.getLatency();
    }
}
