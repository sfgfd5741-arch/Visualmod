package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

/** Небольшой HUD: название мода и список включённых модулей. */
public final class Hud {
    private Hud() {}

    public static void render(DrawContext ctx, RenderTickCounter tickCounter) {
        if (!Config.hud) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;

        ctx.drawText(mc.textRenderer, "VisualMod", 4, 4, 0xFF7C4DFF, true);

        List<String> active = new ArrayList<>();
        if (Config.esp) active.add("ESP");
        if (Config.fullbright) active.add("Fullbright");
        if (Config.viewModel) active.add("ViewModel");
        active.sort((a, b) -> mc.textRenderer.getWidth(b) - mc.textRenderer.getWidth(a));

        int y = 4;
        int right = mc.getWindow().getScaledWidth() - 4;
        for (String s : active) {
            int w = mc.textRenderer.getWidth(s);
            ctx.drawText(mc.textRenderer, s, right - w, y, 0xFFFFFFFF, true);
            y += 10;
        }
    }
}
