package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Меню мода. Открывается и закрывается на Right Shift. */
public class ClickGuiScreen extends Screen {
    private static final int W = 210;
    private static final int ROW = 20;
    private static final int HEADER = 24;
    private static final int ACCENT = 0xFF7C4DFF;

    private interface Row {
        void render(DrawContext ctx, ClickGuiScreen s, int x, int y, int mx, int my);
        boolean click(int x, int y, double mx, double my);
        default void drag(int x, double mx) {}
    }

    private final List<Row> rows = new ArrayList<>();
    private Row dragging = null;
    private int px, py, ph;

    public ClickGuiScreen() {
        super(Text.literal("VisualMod"));
    }

    @Override
    protected void init() {
        rows.clear();
        rows.add(toggle("ESP (подсветка мобов/игроков)", () -> Config.esp, v -> Config.esp = v));
        rows.add(toggle("Fullbright", () -> Config.fullbright, v -> Config.fullbright = v));
        rows.add(toggle("HUD", () -> Config.hud, v -> Config.hud = v));
        rows.add(toggle("ViewModel", () -> Config.viewModel, v -> Config.viewModel = v));
        rows.add(slider("X", -1.0f, 1.0f, () -> Config.vmX, v -> Config.vmX = v));
        rows.add(slider("Y", -1.0f, 1.0f, () -> Config.vmY, v -> Config.vmY = v));
        rows.add(slider("Z", -1.5f, 0.5f, () -> Config.vmZ, v -> Config.vmZ = v));
        rows.add(slider("Размер", 0.3f, 1.5f, () -> Config.vmScale, v -> Config.vmScale = v));

        ph = HEADER + rows.size() * ROW + 6;
        px = (width - W) / 2;
        py = (height - ph) / 2;
    }

    private Row toggle(String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return new Row() {
            @Override
            public void render(DrawContext ctx, ClickGuiScreen s, int x, int y, int mx, int my) {
                boolean on = get.get();
                boolean hover = mx >= x && mx < x + W && my >= y && my < y + ROW;
                ctx.fill(x + 4, y + 1, x + W - 4, y + ROW - 1, hover ? 0xFF2A2A38 : 0xFF1E1E28);
                if (on) ctx.fill(x + 4, y + 1, x + 7, y + ROW - 1, ACCENT);
                ctx.drawText(textRenderer, label, x + 12, y + 6, on ? 0xFFFFFFFF : 0xFF9A9AAA, false);
                ctx.drawText(textRenderer, on ? "ON" : "OFF", x + W - 30, y + 6, on ? ACCENT : 0xFF666677, false);
            }

            @Override
            public boolean click(int x, int y, double mx, double my) {
                if (mx >= x && mx < x + W && my >= y && my < y + ROW) {
                    set.accept(!get.get());
                    return true;
                }
                return false;
            }
        };
    }

    private Row slider(String label, float min, float max, Supplier<Float> get, Consumer<Float> set) {
        final int sx = 62, sw = W - 62 - 40;
        return new Row() {
            @Override
            public void render(DrawContext ctx, ClickGuiScreen s, int x, int y, int mx, int my) {
                float v = get.get();
                float t = (v - min) / (max - min);
                ctx.fill(x + 4, y + 1, x + W - 4, y + ROW - 1, 0xFF1E1E28);
                ctx.drawText(textRenderer, label, x + 12, y + 6, 0xFF9A9AAA, false);
                ctx.fill(x + sx, y + 9, x + sx + sw, y + 11, 0xFF3A3A4A);
                ctx.fill(x + sx, y + 9, x + sx + (int) (sw * t), y + 11, ACCENT);
                int hx = x + sx + (int) (sw * t);
                ctx.fill(hx - 2, y + 5, hx + 2, y + 15, 0xFFFFFFFF);
                ctx.drawText(textRenderer, String.format("%.2f", v), x + W - 36, y + 6, 0xFFFFFFFF, false);
            }

            @Override
            public boolean click(int x, int y, double mx, double my) {
                if (mx >= x + sx - 4 && mx <= x + sx + sw + 4 && my >= y && my < y + ROW) {
                    drag(x, mx);
                    return true;
                }
                return false;
            }

            @Override
            public void drag(int x, double mx) {
                float t = (float) ((mx - (x + sx)) / sw);
                t = Math.max(0f, Math.min(1f, t));
                set.accept(min + t * (max - min));
            }
        };
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x88000000);
        ctx.fill(px, py, px + W, py + ph, 0xF0101018);
        ctx.fill(px, py, px + W, py + HEADER - 4, ACCENT);
        ctx.drawText(textRenderer, "VisualMod", px + 8, py + 6, 0xFFFFFFFF, true);
        ctx.drawText(textRenderer, "RShift - закрыть", px + W - 90, py + 6, 0xFFE0D8FF, false);

        int y = py + HEADER;
        for (Row r : rows) {
            r.render(ctx, this, px, y, mouseX, mouseY);
            y += ROW;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int y = py + HEADER;
            for (Row r : rows) {
                if (r.click(px, y, mouseX, mouseY)) {
                    dragging = r;
                    return true;
                }
                y += ROW;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(px, mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
