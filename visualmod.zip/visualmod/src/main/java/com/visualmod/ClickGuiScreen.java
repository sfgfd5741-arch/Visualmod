package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/** Меню мода: боковые вкладки, переключатели и ползунки. Right Shift открывает/закрывает. */
public class ClickGuiScreen extends Screen {
    private static final int W = 340;
    private static final int H = 214;
    private static final int SIDE = 92;
    private static final int ROW = 22;

    private static final int BG = 0xF2121218;
    private static final int SIDE_BG = 0xFF0D0D12;
    private static final int PANEL = 0xFF1B1B24;
    private static final int PANEL_HOVER = 0xFF242432;
    private static final int OFF = 0xFF3A3A48;
    private static final int TEXT = 0xFFE8E8F0;
    private static final int MUTED = 0xFF8A8A9A;

    private static int tab = 0;
    private static final String[] TAB_NAMES = {"Visuals", "Viewmodel", "Animation", "HUD"};

    private final List<List<Row>> pages = new ArrayList<>();
    private Row dragging = null;
    private int px, py;

    public ClickGuiScreen() {
        super(Text.literal("VisualMod"));
    }

    // ------------------------------------------------------------ строки меню

    private abstract class Row {
        int height() { return ROW; }
        abstract void render(DrawContext c, int x, int y, int w, int mx, int my);
        boolean click(int x, int y, int w, double mx, double my) { return false; }
        void drag(double mx) {}
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean on = get.getAsBoolean();
            pill(c, x, y, w, ROW - 2, in(mx, my, x, y, w, ROW - 2) ? PANEL_HOVER : PANEL);
            c.drawText(textRenderer, label, x + 8, y + 7, on ? TEXT : MUTED, false);

            int sw = 24, sh = 12;
            int sx = x + w - sw - 8;
            int sy = y + 4;
            pill(c, sx, sy, sw, sh, on ? Config.accent() : OFF);
            int kx = on ? sx + sw - 10 : sx + 2;
            pill(c, kx, sy + 2, 8, 8, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (in(mx, my, x, y, w, ROW - 2)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Slider extends Row {
        final String label;
        final float min, max;
        final String fmt;
        final Supplier<Float> get;
        final Consumer<Float> set;
        int trackX, trackW;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            pill(c, x, y, w, ROW - 2, PANEL);
            c.drawText(textRenderer, label, x + 8, y + 7, TEXT, false);

            String value = String.format(fmt, get.get());
            c.drawText(textRenderer, value, x + w - 8 - textRenderer.getWidth(value), y + 7, MUTED, false);

            trackX = x + 72;
            trackW = w - 72 - 50;
            float t = (get.get() - min) / (max - min);
            t = Math.max(0f, Math.min(1f, t));
            int fill = (int) (trackW * t);
            c.fill(trackX, y + 9, trackX + trackW, y + 11, OFF);
            c.fill(trackX, y + 9, trackX + fill, y + 11, Config.accent());
            pill(c, trackX + fill - 3, y + 5, 6, 10, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (in(mx, my, trackX - 4, y, trackW + 8, ROW - 2)) {
                drag(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            float t = (float) ((mx - trackX) / trackW);
            t = Math.max(0f, Math.min(1f, t));
            set.accept(min + t * (max - min));
        }
    }

    private class Button extends Row {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean hov = in(mx, my, x, y, w, ROW - 2);
            pill(c, x, y, w, ROW - 2, hov ? Config.accent() : PANEL_HOVER);
            int tw = textRenderer.getWidth(label);
            c.drawText(textRenderer, label, x + (w - tw) / 2, y + 7, TEXT, false);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (in(mx, my, x, y, w, ROW - 2)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    private class AccentPicker extends Row {
        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            pill(c, x, y, w, ROW - 2, in(mx, my, x, y, w, ROW - 2) ? PANEL_HOVER : PANEL);
            c.drawText(textRenderer, "Accent color", x + 8, y + 7, TEXT, false);
            String name = Config.accentName();
            int nw = textRenderer.getWidth(name);
            c.drawText(textRenderer, name, x + w - 8 - nw, y + 7, MUTED, false);
            pill(c, x + w - 8 - nw - 16, y + 5, 10, 10, Config.accent());
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (in(mx, my, x, y, w, ROW - 2)) {
                Config.accent++;
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------ вспомогательное

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Прямоугольник со скруглёнными углами (радиус 1 пиксель). */
    private static void pill(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x + 1, y, x + w - 1, y + h, color);
        c.fill(x, y + 1, x + w, y + h - 1, color);
    }

    // ------------------------------------------------------------ экран

    @Override
    protected void init() {
        pages.clear();

        List<Row> visuals = new ArrayList<>();
        visuals.add(new Toggle("ESP", () -> Config.esp, v -> Config.esp = v));
        visuals.add(new Toggle("Fullbright", () -> Config.fullbright, v -> Config.fullbright = v));
        visuals.add(new Toggle("NameTags", () -> Config.nameTags, v -> Config.nameTags = v));
        visuals.add(new Toggle("Item Physics", () -> Config.itemPhysics, v -> Config.itemPhysics = v));
        pages.add(visuals);

        List<Row> view = new ArrayList<>();
        view.add(new Toggle("ViewModel", () -> Config.viewModel, v -> Config.viewModel = v));
        view.add(new Slider("X", -1.0f, 1.0f, "%.2f", () -> Config.vmX, v -> Config.vmX = v));
        view.add(new Slider("Y", -1.0f, 1.0f, "%.2f", () -> Config.vmY, v -> Config.vmY = v));
        view.add(new Slider("Z", -1.5f, 0.5f, "%.2f", () -> Config.vmZ, v -> Config.vmZ = v));
        view.add(new Slider("Scale", 0.3f, 1.5f, "%.2f", () -> Config.vmScale, v -> Config.vmScale = v));
        view.add(new Button("Reset viewmodel", Config::resetViewModel));
        pages.add(view);

        List<Row> anim = new ArrayList<>();
        anim.add(new Toggle("Swing Animation", () -> Config.swingAnim, v -> Config.swingAnim = v));
        anim.add(new Slider("Speed", 2.0f, 20.0f, "%.0f", () -> Config.swingSpeed,
                v -> Config.swingSpeed = Math.round(v)));
        anim.add(new Slider("Angle", -60.0f, 60.0f, "%.0f", () -> Config.swingAngle,
                v -> Config.swingAngle = Math.round(v)));
        pages.add(anim);

        List<Row> hud = new ArrayList<>();
        hud.add(new Toggle("HUD", () -> Config.hud, v -> Config.hud = v));
        hud.add(new Toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v));
        hud.add(new Toggle("Module list", () -> Config.hudModuleList, v -> Config.hudModuleList = v));
        hud.add(new Toggle("Info (FPS, ping, XYZ)", () -> Config.hudInfo, v -> Config.hudInfo = v));
        hud.add(new AccentPicker());
        pages.add(hud);

        px = Math.max(0, (width - W) / 2);
        py = Math.max(2, (height - H) / 2);
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        int accent = Config.accent();

        c.fill(0, 0, width, height, 0x80000000);

        // окно
        pill(c, px - 1, py - 1, W + 2, H + 2, 0x55000000);
        pill(c, px, py, W, H, BG);
        c.fill(px + 1, py, px + W - 1, py + 2, accent);

        // боковая панель
        c.fill(px + 1, py + 2, px + SIDE, py + H - 1, SIDE_BG);
        int nameX = px + 14;
        c.drawText(textRenderer, "Visual", nameX, py + 12, TEXT, true);
        c.drawText(textRenderer, "Mod", nameX + textRenderer.getWidth("Visual"), py + 12, accent, true);

        for (int i = 0; i < TAB_NAMES.length; i++) {
            int ty = py + 36 + i * 24;
            boolean sel = i == tab;
            boolean hov = in(mouseX, mouseY, px + 6, ty, SIDE - 12, 20);
            if (sel || hov) pill(c, px + 6, ty, SIDE - 12, 20, sel ? PANEL_HOVER : PANEL);
            if (sel) c.fill(px + 6, ty + 4, px + 8, ty + 16, accent);
            c.drawText(textRenderer, TAB_NAMES[i], px + 16, ty + 6, sel ? TEXT : MUTED, false);
        }
        c.drawText(textRenderer, "RShift - close", px + 10, py + H - 14, 0xFF5A5A6A, false);

        // содержимое вкладки
        int cx = px + SIDE + 12;
        int cw = W - SIDE - 24;
        c.drawText(textRenderer, TAB_NAMES[tab], cx + 2, py + 12, TEXT, true);
        c.fill(cx, py + 25, cx + cw, py + 26, 0xFF2A2A36);

        int y = py + 32;
        for (Row r : pages.get(tab)) {
            r.render(c, cx, y, cw, mouseX, mouseY);
            y += r.height();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = 0; i < TAB_NAMES.length; i++) {
                int ty = py + 36 + i * 24;
                if (in(mouseX, mouseY, px + 6, ty, SIDE - 12, 20)) {
                    tab = i;
                    return true;
                }
            }
            int cx = px + SIDE + 12;
            int cw = W - SIDE - 24;
            int y = py + 32;
            for (Row r : pages.get(tab)) {
                if (r.click(cx, y, cw, mouseX, mouseY)) {
                    dragging = r;
                    return true;
                }
                y += r.height();
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mouseX);
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
