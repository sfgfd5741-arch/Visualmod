package com.visualmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * NameTags: свои ники над игроками (ник, здоровье, дистанция).
 * Позиция считается в мировом рендере, рисуется в HUD, поэтому видно и сквозь стены.
 */
public final class NameTags {
    private NameTags() {}

    private record Tag(float x, float y, String name, float health, float maxHealth, double dist) {}

    private static final List<Tag> TAGS = new ArrayList<>();

    public static void collect(WorldRenderContext ctx) {
        TAGS.clear();
        if (!Config.nameTags) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        float tickDelta = ctx.tickCounter().getTickDelta(true);
        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;

            Vec3d pos = p.getLerpedPos(tickDelta);
            double dx = pos.x - cam.x;
            double dy = pos.y + p.getHeight() + 0.35 - cam.y;
            double dz = pos.z - cam.z;

            Vector4f v = new Vector4f((float) dx, (float) dy, (float) dz, 1.0f);
            v.mul(view);
            v.mul(proj);
            if (v.w <= 0.05f) continue;

            float nx = v.x / v.w;
            float ny = v.y / v.w;
            if (Math.abs(nx) > 1.2f || Math.abs(ny) > 1.2f) continue;

            float x = (nx * 0.5f + 0.5f) * sw;
            float y = (1.0f - (ny * 0.5f + 0.5f)) * sh;
            double dist = Math.sqrt(dx * dx + (pos.y - cam.y) * (pos.y - cam.y) + dz * dz);

            TAGS.add(new Tag(x, y, p.getName().getString(), p.getHealth(), p.getMaxHealth(), dist));
        }
        // дальние рисуем первыми, ближние сверху
        TAGS.sort((a, b) -> Double.compare(b.dist(), a.dist()));
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!Config.nameTags || TAGS.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        int accent = Config.accent();
        for (Tag t : TAGS) {
            float scale = MathHelper.clamp(1.4f - (float) t.dist() / 40.0f, 0.65f, 1.2f);
            String name = t.name();
            String info = Math.round(t.health()) + "hp  " + (int) t.dist() + "m";
            int nameW = mc.textRenderer.getWidth(name);
            int infoW = mc.textRenderer.getWidth(info);
            int w = nameW + 10 + infoW + 10;
            int x0 = -w / 2;
            int y0 = -18;

            float frac = MathHelper.clamp(t.health() / Math.max(1.0f, t.maxHealth()), 0.0f, 1.0f);
            int hpColor = 0xFF000000 | MathHelper.hsvToRgb(frac * 0.33f, 0.75f, 1.0f);

            MatrixStack m = c.getMatrices();
            m.push();
            m.translate(t.x(), t.y(), 0.0);
            m.scale(scale, scale, 1.0f);

            c.fill(x0, y0, x0 + w, y0 + 14, 0xB0101018);
            c.fill(x0, y0 + 14, x0 + w, y0 + 16, 0xB0000000);
            c.fill(x0, y0 + 14, x0 + (int) (w * frac), y0 + 16, hpColor);
            c.fill(x0, y0, x0 + 2, y0 + 14, accent);
            c.drawText(mc.textRenderer, name, x0 + 6, y0 + 3, 0xFFFFFFFF, true);
            c.drawText(mc.textRenderer, info, x0 + 6 + nameW + 10, y0 + 3, 0xFFA8A8B8, true);

            m.pop();
        }
    }
}
