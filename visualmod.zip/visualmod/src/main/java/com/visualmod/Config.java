package com.visualmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Все настройки мода. Сохраняются в config/visualmod.properties. */
public final class Config {
    private Config() {}

    // Visuals
    public static boolean esp = false;
    public static boolean fullbright = false;
    public static boolean nameTags = false;
    public static boolean itemPhysics = false;

    // ViewModel
    public static boolean viewModel = false;
    public static float vmX = 0.0f;
    public static float vmY = 0.0f;
    public static float vmZ = 0.0f;
    public static float vmScale = 1.0f;

    // Swing animation
    public static boolean swingAnim = false;
    public static float swingSpeed = 6.0f;   // длительность взмаха в тиках (меньше = быстрее)
    public static float swingAngle = 0.0f;   // дополнительный наклон руки при взмахе

    // HUD
    public static boolean hud = true;
    public static boolean hudWatermark = true;
    public static boolean hudModuleList = true;
    public static boolean hudInfo = true;

    // Тема
    public static int accent = 0;
    public static final int[] ACCENTS = {0xFF7C4DFF, 0xFF00BCD4, 0xFFFF5252, 0xFF69F0AE, 0xFFFFB300};
    public static final String[] ACCENT_NAMES = {"Violet", "Cyan", "Red", "Green", "Amber"};

    public static int accent() {
        return ACCENTS[Math.floorMod(accent, ACCENTS.length)];
    }

    public static String accentName() {
        return ACCENT_NAMES[Math.floorMod(accent, ACCENT_NAMES.length)];
    }

    public static void resetViewModel() {
        vmX = 0.0f;
        vmY = 0.0f;
        vmZ = 0.0f;
        vmScale = 1.0f;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("visualmod.properties");
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("esp", String.valueOf(esp));
        p.setProperty("fullbright", String.valueOf(fullbright));
        p.setProperty("nameTags", String.valueOf(nameTags));
        p.setProperty("itemPhysics", String.valueOf(itemPhysics));
        p.setProperty("viewModel", String.valueOf(viewModel));
        p.setProperty("vmX", String.valueOf(vmX));
        p.setProperty("vmY", String.valueOf(vmY));
        p.setProperty("vmZ", String.valueOf(vmZ));
        p.setProperty("vmScale", String.valueOf(vmScale));
        p.setProperty("swingAnim", String.valueOf(swingAnim));
        p.setProperty("swingSpeed", String.valueOf(swingSpeed));
        p.setProperty("swingAngle", String.valueOf(swingAngle));
        p.setProperty("hud", String.valueOf(hud));
        p.setProperty("hudWatermark", String.valueOf(hudWatermark));
        p.setProperty("hudModuleList", String.valueOf(hudModuleList));
        p.setProperty("hudInfo", String.valueOf(hudInfo));
        p.setProperty("accent", String.valueOf(accent));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "VisualMod");
        } catch (IOException ignored) {
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        esp = bool(p, "esp", esp);
        fullbright = bool(p, "fullbright", fullbright);
        nameTags = bool(p, "nameTags", nameTags);
        itemPhysics = bool(p, "itemPhysics", itemPhysics);
        viewModel = bool(p, "viewModel", viewModel);
        vmX = flt(p, "vmX", vmX);
        vmY = flt(p, "vmY", vmY);
        vmZ = flt(p, "vmZ", vmZ);
        vmScale = flt(p, "vmScale", vmScale);
        swingAnim = bool(p, "swingAnim", swingAnim);
        swingSpeed = flt(p, "swingSpeed", swingSpeed);
        swingAngle = flt(p, "swingAngle", swingAngle);
        hud = bool(p, "hud", hud);
        hudWatermark = bool(p, "hudWatermark", hudWatermark);
        hudModuleList = bool(p, "hudModuleList", hudModuleList);
        hudInfo = bool(p, "hudInfo", hudInfo);
        accent = (int) flt(p, "accent", accent);
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static float flt(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
