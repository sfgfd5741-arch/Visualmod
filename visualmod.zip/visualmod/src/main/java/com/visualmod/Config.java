package com.visualmod;

/** Все настройки мода в одном месте. */
public final class Config {
    private Config() {}

    // Модули
    public static boolean esp = false;
    public static boolean fullbright = false;
    public static boolean viewModel = false;
    public static boolean hud = true;

    // ViewModel
    public static float vmX = 0.0f;
    public static float vmY = 0.0f;
    public static float vmZ = 0.0f;
    public static float vmScale = 1.0f;
}
