package com.visualmod;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Все настройки мода. Сохраняются в config/visualmod.properties. */
public final class Config {
    private Config() {}

    // Visuals
    public static boolean esp = false;
    public static int espMode = 0;           // 0 = Box, 1 = Glow
    public static boolean espMobs = false;   // Box ESP и для мобов
    public static boolean seeInvisibles = false;
    public static boolean fullbright = false;
    public static boolean nameTags = false;
    public static boolean itemPhysics = false;

    // ViewModel
    public static boolean viewModel = false;
    public static float vmX = 0.0f;
    public static float vmY = 0.0f;
    public static float vmZ = 0.0f;
    public static float vmScale = 1.0f;

    // Swing animation
    public static boolean swingAnim = false;
    public static float swingSpeed = 6.0f;   // длительность взмаха в тиках (меньше = быстрее)
    public static float swingAngle = 0.0f;   // дополнительный наклон руки при взмахе
    public static int swingStyle = 1;        // 0 = Vanilla, 1 = Sideways, 2 = Push
    public static final String[] SWING_STYLES = {"Vanilla", "Sideways", "Push"};

    // HUD
    public static boolean hud = true;
    public static boolean hudWatermark = true;
    public static boolean hudModuleList = true;
    public static boolean hudInfo = true;
    public static boolean hudKeys = true;
    public static int font = 0;   // 0 Vanilla (всегда работает), 1 JetBrains Mono, 2 Geist Mono, 3 Carlito
    public static final String[] FONT_NAMES = {"Vanilla", "JetBrains", "Geist", "Carlito"};

    // Misc
    public static boolean autoSprint = false;
    public static final int HUD_ELEMS = 4;
    /** Позиции HUD: 0 = watermark, 1 = info, 2 = module list (x = ПРАВЫЙ край, -1 = по умолчанию), 3 = keystrokes. */
    public static int[] hudX = {4, 4, -1, 4};
    public static int[] hudY = {4, 23, 4, 44};

    // Тема
    public static int accent = 0;
    public static final int[] ACCENTS = {0xFF7C4DFF, 0xFF00BCD4, 0xFFFF5252, 0xFF69F0AE, 0xFFFFB300};
    public static final String[] ACCENT_NAMES = {"Violet", "Cyan", "Red", "Green", "Amber"};

    public static int accent() {
        return ACCENTS[Math.floorMod(accent, ACCENTS.length)];
    }

    public static String accentName() {
        return ACCENT_NAMES[Math.floorMod(accent, ACCENT_NAMES.length)];
    }

    public static void resetHud() {
        hudX = new int[]{4, 4, -1, 4};
        hudY = new int[]{4, 23, 4, 44};
    }

    public static void resetViewModel() {
        vmX = 0.0f;
        vmY = 0.0f;
        vmZ = 0.0f;
        vmScale = 1.0f;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("visualmod.properties");
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("esp", String.valueOf(esp));
        p.setProperty("espMode", String.valueOf(espMode));
        p.setProperty("espMobs", String.valueOf(espMobs));
        p.setProperty("seeInvisibles", String.valueOf(seeInvisibles));
        p.setProperty("swingStyle", String.valueOf(swingStyle));
        p.setProperty("fontId", String.valueOf(font));
        p.setProperty("hudKeys", String.valueOf(hudKeys));
        p.setProperty("autoSprint", String.valueOf(autoSprint));
        for (int i = 0; i < HUD_ELEMS; i++) {
            p.setProperty("hudX" + i, String.valueOf(hudX[i]));
            p.setProperty("hudY" + i, String.valueOf(hudY[i]));
        }
        p.setProperty("fullbright", String.valueOf(fullbright));
        p.setProperty("nameTags", String.valueOf(nameTags));
        p.setProperty("itemPhysics", String.valueOf(itemPhysics));
        p.setProperty("viewModel", String.valueOf(viewModel));
        p.setProperty("vmX", String.valueOf(vmX));
        p.setProperty("vmY", String.valueOf(vmY));
        p.setProperty("vmZ", String.valueOf(vmZ));
        p.setProperty("vmScale", String.valueOf(vmScale));
        p.setProperty("swingAnim", String.valueOf(swingAnim));
        p.setProperty("swingSpeed", String.valueOf(swingSpeed));
        p.setProperty("swingAngle", String.valueOf(swingAngle));
        p.setProperty("hud", String.valueOf(hud));
        p.setProperty("hudWatermark", String.valueOf(hudWatermark));
        p.setProperty("hudModuleList", String.valueOf(hudModuleList));
        p.setProperty("hudInfo", String.valueOf(hudInfo));
        p.setProperty("accent", String.valueOf(accent));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "VisualMod");
        } catch (IOException ignored) {
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        esp = bool(p, "esp", esp);
        espMode = Math.floorMod((int) flt(p, "espMode", espMode), 2);
        espMobs = bool(p, "espMobs", espMobs);
        seeInvisibles = bool(p, "seeInvisibles", seeInvisibles);
        swingStyle = Math.floorMod((int) flt(p, "swingStyle", swingStyle), SWING_STYLES.length);
        font = Math.floorMod((int) flt(p, "fontId", font), FONT_NAMES.length);
        hudKeys = bool(p, "hudKeys", hudKeys);
        autoSprint = bool(p, "autoSprint", autoSprint);
        for (int i = 0; i < HUD_ELEMS; i++) {
            hudX[i] = (int) flt(p, "hudX" + i, hudX[i]);
            hudY[i] = (int) flt(p, "hudY" + i, hudY[i]);
        }
        fullbright = bool(p, "fullbright", fullbright);
        nameTags = bool(p, "nameTags", nameTags);
        itemPhysics = bool(p, "itemPhysics", itemPhysics);
        viewModel = bool(p, "viewModel", viewModel);
        vmX = flt(p, "vmX", vmX);
        vmY = flt(p, "vmY", vmY);
        vmZ = flt(p, "vmZ", vmZ);
        vmScale = flt(p, "vmScale", vmScale);
        swingAnim = bool(p, "swingAnim", swingAnim);
        swingSpeed = flt(p, "swingSpeed", swingSpeed);
        swingAngle = flt(p, "swingAngle", swingAngle);
        hud = bool(p, "hud", hud);
        hudWatermark = bool(p, "hudWatermark", hudWatermark);
        hudModuleList = bool(p, "hudModuleList", hudModuleList);
        hudInfo = bool(p, "hudInfo", hudInfo);
        accent = (int) flt(p, "accent", accent);
    }

    private static boolean bool(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static float flt(Properties p, String key, float def) {
        String v = p.getProperty(key);
        if (v == null) return def;
        try {
            return Float.parseFloat(v);
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
