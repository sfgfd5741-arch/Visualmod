package com.visualmod;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Общие помощники для рисования: шрифты, скруглённые прямоугольники. */
public final class Ui {
    private Ui() {}

    private static Style font(String id) {
        return Style.EMPTY.withFont(Identifier.of("visualmod", id));
    }

    /** 0 = ванильный шрифт, остальные - TTF из assets/visualmod/font. */
    private static final Style[] FONTS = {null, font("ui_jetbrains"), font("ui_geist"), font("ui_carlito")};

    /** Высота заглавных букв: по ней центруем текст по вертикали. */
    public static final int CAP = 7;

    public static Text t(String s) {
        MutableText m = Text.literal(s);
        Style st = FONTS[Math.floorMod(Config.font, FONTS.length)];
        return st == null ? m : m.setStyle(st);
    }

    public static int width(TextRenderer tr, String s) {
        return tr.getWidth(t(s));
    }

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawText(tr, t(s), x, y, color, false);
    }

    /** Текст, выровненный по центру строки высотой h. */
    public static void textMid(DrawContext c, TextRenderer tr, String s, int x, int y, int h, int color) {
        text(c, tr, s, x, y + (h - CAP) / 2, color);
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    /** Скруглённый прямоугольник со сглаженными (антиалиасинг) углами. r = h/2 даёт капсулу. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        if (y + r < y + h - r) c.fill(x, y + r, x + w, y + h - r, color);
        int alpha = color >>> 24;
        int rgb = color & 0xFFFFFF;
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            double inset = r - Math.sqrt((double) r * r - dy * dy);
            int full = (int) Math.ceil(inset);
            if (x + full >= x + w - full) continue;
            c.fill(x + full, y + i, x + w - full, y + i + 1, color);
            c.fill(x + full, y + h - 1 - i, x + w - full, y + h - i, color);
            double cov = full - inset;
            if (full > 0 && cov > 0.05) {
                int edge = (Math.round((float) (alpha * cov)) << 24) | rgb;
                c.fill(x + full - 1, y + i, x + full, y + i + 1, edge);
                c.fill(x + w - full, y + i, x + w - full + 1, y + i + 1, edge);
                c.fill(x + full - 1, y + h - 1 - i, x + full, y + h - i, edge);
                c.fill(x + w - full, y + h - 1 - i, x + w - full + 1, y + h - i, edge);
            }
        }
    }

    public static void capsule(DrawContext c, int x, int y, int w, int h, int color) {
        rrect(c, x, y, w, h, h / 2, color);
    }
}
