package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** ESP: включает ванильную обводку (glow) для живых существ. */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public ClientPlayerEntity player;

    @Inject(method = "hasOutline", at = @At("HEAD"), cancellable = true)
    private void visualmod$esp(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (Config.esp && entity instanceof LivingEntity && entity != this.player) {
            cir.setReturnValue(true);
        }
    }
}
