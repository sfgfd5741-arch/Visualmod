package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Прячет ванильные ники игроков, когда включены NameTags. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;D)Z",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void visualmod$hideVanillaTag(LivingEntity entity, double squaredDistance,
                                          CallbackInfoReturnable<Boolean> cir) {
        if (Config.nameTags && entity instanceof PlayerEntity) {
            cir.setReturnValue(false);
        }
    }
}
