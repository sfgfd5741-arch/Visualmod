package com.visualmod.mixin;

import com.visualmod.Config;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** ViewModel (положение/размер предмета) и дополнительный наклон при взмахе. */
@Mixin(HeldItemRenderer.class)
public class HeldItemRendererMixin {
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void visualmod$viewModel(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                     Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                     MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
                                     CallbackInfo ci) {
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        float side = arm == Arm.RIGHT ? 1.0f : -1.0f;

        if (Config.viewModel) {
            matrices.translate(Config.vmX * side, Config.vmY, Config.vmZ);
            matrices.scale(Config.vmScale, Config.vmScale, Config.vmScale);
        }

        if (Config.swingAnim && swingProgress > 0.0f && Config.swingAngle != 0.0f) {
            float s = (float) Math.sin(swingProgress * Math.PI);
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-Config.swingAngle * s));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(Config.swingAngle * 0.5f * s * side));
        }
    }
}
