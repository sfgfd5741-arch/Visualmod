# noomi visuals (Fabric 1.21.4)

Меню: **Right Shift** (открыть/закрыть). Окно можно двигать за пустое место. Настройки: `config/visualmod.properties`.

Вкладки:
- **Visuals:** ESP (режимы Box / Glow, мобы), See invisibles, NameTags, Fullbright, Item Physics
- **Viewmodel:** положение (X/Y/Z) и размер предмета в руке
- **Animation:** Swing Animation, стиль (Vanilla / Sideways / Push), скорость, наклон
- **HUD:** watermark "noomi visuals", координаты, список модулей, цвет, шрифт, кнопка **Move HUD** (таскаешь блоки мышкой)

Шрифт меню: Carlito (SIL OFL 1.1, лицензия в `assets/visualmod/font/`). Не нравится - вкл/выкл "Smooth font" в HUD.

## Сборка
Нужна Java 21.

    gradlew build        (Windows)
    ./gradlew build      (Linux/macOS)

Мод: `build/libs/noomi-visuals-1.0.0.jar` (не `-sources`). Кладите в `mods` вместе с Fabric API 0.119.2+1.21.4.
