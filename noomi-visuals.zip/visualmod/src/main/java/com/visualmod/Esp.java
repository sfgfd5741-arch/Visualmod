package com.visualmod;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Box ESP: рамка с уголками и полоской здоровья вокруг игроков (и по желанию мобов).
 * Позиции считаются в мировом рендере, рисуются в HUD, поэтому рамка видна и сквозь стены.
 */
public final class Esp {
    private Esp() {}

    private record Frame(int x1, int y1, int x2, int y2, float hp, boolean player) {}

    private static final List<Frame> FRAMES = new ArrayList<>();

    public static boolean boxMode() {
        return Config.esp && Config.espMode == 0;
    }

    public static void collect(WorldRenderContext ctx) {
        FRAMES.clear();
        if (!boxMode()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        float td = ctx.tickCounter().getTickDelta(true);
        Vec3d cam = ctx.camera().getPos();
        Matrix4f view = ctx.positionMatrix();
        Matrix4f proj = ctx.projectionMatrix();
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player || e instanceof ArmorStandEntity) continue;
            boolean player = e instanceof PlayerEntity;
            if (!player && !Config.espMobs) continue;
            if (!le.isAlive()) continue;

            Vec3d lerp = e.getLerpedPos(td);
            Vec3d off = lerp.subtract(e.getPos());
            Box b = e.getBoundingBox();

            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean ok = true;
            for (int i = 0; i < 8 && ok; i++) {
                double cx = ((i & 1) == 0 ? b.minX : b.maxX) + off.x - cam.x;
                double cy = ((i & 2) == 0 ? b.minY : b.maxY) + off.y - cam.y;
                double cz = ((i & 4) == 0 ? b.minZ : b.maxZ) + off.z - cam.z;
                Vector4f v = new Vector4f((float) cx, (float) cy, (float) cz, 1.0f);
                v.mul(view);
                v.mul(proj);
                if (v.w <= 0.05f) {
                    ok = false;
                    break;
                }
                float sx = (v.x / v.w * 0.5f + 0.5f) * sw;
                float sy = (1.0f - (v.y / v.w * 0.5f + 0.5f)) * sh;
                minX = Math.min(minX, sx);
                maxX = Math.max(maxX, sx);
                minY = Math.min(minY, sy);
                maxY = Math.max(maxY, sy);
            }
            if (!ok) continue;
            if (maxX < -20 || minX > sw + 20 || maxY < -20 || minY > sh + 20) continue;

            float hp = MathHelper.clamp(le.getHealth() / Math.max(1.0f, le.getMaxHealth()), 0.0f, 1.0f);
            FRAMES.add(new Frame(Math.round(minX), Math.round(minY), Math.round(maxX), Math.round(maxY), hp, player));
        }
    }

    public static void draw(DrawContext c, RenderTickCounter tickCounter) {
        if (!boxMode() || FRAMES.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;

        int accent = Config.accent();
        for (Frame f : FRAMES) {
            int x1 = f.x1(), y1 = f.y1(), x2 = f.x2(), y2 = f.y2();
            int w = x2 - x1, h = y2 - y1;
            if (w < 4 || h < 4) continue;
            int col = f.player() ? accent : 0xFFFFFFFF;

            // лёгкая заливка
            Ui.rrect(c, x1, y1, w, h, Math.min(6, Math.min(w, h) / 3), (col & 0xFFFFFF) | 0x14000000);

            // уголки: тёмная подложка 3px + цветная линия 1px
            int len = Math.max(4, Math.min(w, h) / 4);
            corners(c, x1, y1, x2, y2, len, 0xFF000000, 1);
            corners(c, x1, y1, x2, y2, len, col, 0);

            // здоровье слева
            int bx = x1 - 5;
            int hh = h;
            c.fill(bx - 1, y1 - 1, bx + 3, y1 + hh + 1, 0xFF000000);
            int fill = Math.round(hh * f.hp());
            int hpColor = 0xFF000000 | MathHelper.hsvToRgb(f.hp() * 0.33f, 0.75f, 1.0f);
            c.fill(bx, y1 + hh - fill, bx + 2, y1 + hh, hpColor);
        }
    }

    /** pad = 1 рисует подложку на пиксель шире со всех сторон. */
    private static void corners(DrawContext c, int x1, int y1, int x2, int y2, int len, int color, int pad) {
        int p = pad;
        // левый верх
        c.fill(x1 - p, y1 - p, x1 + len + p, y1 + 1 + p, color);
        c.fill(x1 - p, y1 - p, x1 + 1 + p, y1 + len + p, color);
        // правый верх
        c.fill(x2 - len - p, y1 - p, x2 + p, y1 + 1 + p, color);
        c.fill(x2 - 1 - p, y1 - p, x2 + p, y1 + len + p, color);
        // левый низ
        c.fill(x1 - p, y2 - 1 - p, x1 + len + p, y2 + p, color);
        c.fill(x1 - p, y2 - len - p, x1 + 1 + p, y2 + p, color);
        // правый низ
        c.fill(x2 - len - p, y2 - 1 - p, x2 + p, y2 + p, color);
        c.fill(x2 - 1 - p, y2 - len - p, x2 + p, y2 + p, color);
    }
}
