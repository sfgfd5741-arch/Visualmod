package com.visualmod;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Меню noomi visuals: круглые плашки, ровный шрифт, окно можно двигать за пустое место. */
public class ClickGuiScreen extends Screen {
    private static final int W = 364;
    private static final int H = 232;
    private static final int SIDE = 96;
    private static final int STRIDE = 22;   // шаг строк
    private static final int RH = 20;       // высота строки

    private static final int BORDER = 0xFF2C2C3A;
    private static final int BG = 0xFF14141B;
    private static final int SIDE_BG = 0xFF0E0E13;
    private static final int PANEL = 0xFF1E1E29;
    private static final int PANEL_HOVER = 0xFF2A2A38;
    private static final int OFF = 0xFF3C3C4C;
    private static final int TEXT = 0xFFEDEDF5;
    private static final int MUTED = 0xFF8E8E9F;

    private static int tab = 0;
    private static final String[] TAB_NAMES = {"Visuals", "Viewmodel", "Animation", "HUD"};

    // позиция окна запоминается между открытиями
    private static boolean placed = false;
    private static int winX, winY;

    private final List<List<Row>> pages = new ArrayList<>();
    private Row dragging = null;
    private boolean movingWindow = false;
    private int px, py;

    public ClickGuiScreen() {
        super(Text.literal("noomi visuals"));
    }

    // ------------------------------------------------------------ строки меню

    private abstract class Row {
        int height() { return STRIDE; }
        abstract void render(DrawContext c, int x, int y, int w, int mx, int my);
        boolean click(int x, int y, int w, double mx, double my) { return false; }
        void drag(double mx) {}
    }

    private class Toggle extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;

        Toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean on = get.getAsBoolean();
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, on ? TEXT : MUTED);

            int sw = 28, sh = 12;
            int sx = x + w - sw - 8;
            int sy = y + (RH - sh) / 2;
            Ui.capsule(c, sx, sy, sw, sh, on ? Config.accent() : OFF);
            int kx = on ? sx + sw - sh + 2 : sx + 2;
            Ui.capsule(c, kx, sy + 2, sh - 4, sh - 4, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    private class Cycle extends Row {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        Cycle(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);
            String v = options[Math.floorMod(get.getAsInt(), options.length)];
            int vw = Ui.width(textRenderer, v) + 16;
            int vx = x + w - vw - 4;
            Ui.capsule(c, vx, y + 3, vw, RH - 6, Config.accent());
            Ui.textMid(c, textRenderer, v, vx + 8, y, RH, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                set.accept(Math.floorMod(get.getAsInt() + 1, options.length));
                return true;
            }
            return false;
        }
    }

    private class Slider extends Row {
        final String label;
        final float min, max;
        final String fmt;
        final Supplier<Float> get;
        final Consumer<Float> set;
        int trackX, trackW;

        Slider(String label, float min, float max, String fmt, Supplier<Float> get, Consumer<Float> set) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.fmt = fmt;
            this.get = get;
            this.set = set;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, PANEL);
            Ui.textMid(c, textRenderer, label, x + 12, y, RH, TEXT);

            String value = String.format(fmt, get.get());
            Ui.textMid(c, textRenderer, value, x + w - 12 - Ui.width(textRenderer, value), y, RH, MUTED);

            trackX = x + 74;
            trackW = w - 74 - 54;
            float t = (get.get() - min) / (max - min);
            t = Math.max(0f, Math.min(1f, t));
            int fill = Math.round(trackW * t);
            int ty = y + (RH - 4) / 2;
            Ui.capsule(c, trackX, ty, trackW, 4, OFF);
            if (fill > 0) Ui.capsule(c, trackX, ty, Math.max(4, fill), 4, Config.accent());
            Ui.capsule(c, trackX + fill - 4, y + (RH - 8) / 2, 8, 8, 0xFFFFFFFF);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, trackX - 6, y, trackW + 12, RH)) {
                drag(mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(double mx) {
            float t = (float) ((mx - trackX) / trackW);
            t = Math.max(0f, Math.min(1f, t));
            set.accept(min + t * (max - min));
        }
    }

    private class Button extends Row {
        final String label;
        final Runnable action;

        Button(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            boolean hov = Ui.in(mx, my, x, y, w, RH);
            Ui.capsule(c, x, y, w, RH, hov ? Config.accent() : PANEL_HOVER);
            int tw = Ui.width(textRenderer, label);
            Ui.textMid(c, textRenderer, label, x + (w - tw) / 2, y, RH, TEXT);
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                action.run();
                return true;
            }
            return false;
        }
    }

    private class AccentPicker extends Row {
        @Override
        void render(DrawContext c, int x, int y, int w, int mx, int my) {
            Ui.capsule(c, x, y, w, RH, Ui.in(mx, my, x, y, w, RH) ? PANEL_HOVER : PANEL);
            Ui.textMid(c, textRenderer, "Accent color", x + 12, y, RH, TEXT);
            String name = Config.accentName();
            int nw = Ui.width(textRenderer, name);
            Ui.textMid(c, textRenderer, name, x + w - 12 - nw, y, RH, MUTED);
            Ui.capsule(c, x + w - 12 - nw - 16, y + (RH - 10) / 2, 10, 10, Config.accent());
        }

        @Override
        boolean click(int x, int y, int w, double mx, double my) {
            if (Ui.in(mx, my, x, y, w, RH)) {
                Config.accent++;
                return true;
            }
            return false;
        }
    }

    // ------------------------------------------------------------ экран

    @Override
    protected void init() {
        pages.clear();

        List<Row> visuals = new ArrayList<>();
        visuals.add(new Toggle("ESP", () -> Config.esp, v -> Config.esp = v));
        visuals.add(new Cycle("ESP mode", new String[]{"Box", "Glow"}, () -> Config.espMode, v -> Config.espMode = v));
        visuals.add(new Toggle("ESP mobs (Box)", () -> Config.espMobs, v -> Config.espMobs = v));
        visuals.add(new Toggle("See invisibles", () -> Config.seeInvisibles, v -> Config.seeInvisibles = v));
        visuals.add(new Toggle("NameTags", () -> Config.nameTags, v -> Config.nameTags = v));
        visuals.add(new Toggle("Fullbright", () -> Config.fullbright, v -> Config.fullbright = v));
        visuals.add(new Toggle("Item Physics", () -> Config.itemPhysics, v -> Config.itemPhysics = v));
        pages.add(visuals);

        List<Row> view = new ArrayList<>();
        view.add(new Toggle("ViewModel", () -> Config.viewModel, v -> Config.viewModel = v));
        view.add(new Slider("X", -1.0f, 1.0f, "%.2f", () -> Config.vmX, v -> Config.vmX = v));
        view.add(new Slider("Y", -1.0f, 1.0f, "%.2f", () -> Config.vmY, v -> Config.vmY = v));
        view.add(new Slider("Z", -1.5f, 0.5f, "%.2f", () -> Config.vmZ, v -> Config.vmZ = v));
        view.add(new Slider("Scale", 0.3f, 1.5f, "%.2f", () -> Config.vmScale, v -> Config.vmScale = v));
        view.add(new Button("Reset viewmodel", Config::resetViewModel));
        pages.add(view);

        List<Row> anim = new ArrayList<>();
        anim.add(new Toggle("Swing Animation", () -> Config.swingAnim, v -> Config.swingAnim = v));
        anim.add(new Cycle("Style", Config.SWING_STYLES, () -> Config.swingStyle, v -> Config.swingStyle = v));
        anim.add(new Slider("Speed", 2.0f, 20.0f, "%.0f", () -> Config.swingSpeed,
                v -> Config.swingSpeed = Math.round(v)));
        anim.add(new Slider("Angle", -60.0f, 60.0f, "%.0f", () -> Config.swingAngle,
                v -> Config.swingAngle = Math.round(v)));
        pages.add(anim);

        List<Row> hud = new ArrayList<>();
        hud.add(new Toggle("HUD", () -> Config.hud, v -> Config.hud = v));
        hud.add(new Toggle("Watermark", () -> Config.hudWatermark, v -> Config.hudWatermark = v));
        hud.add(new Toggle("Module list", () -> Config.hudModuleList, v -> Config.hudModuleList = v));
        hud.add(new Toggle("Info (FPS, ping, XYZ)", () -> Config.hudInfo, v -> Config.hudInfo = v));
        hud.add(new Toggle("Smooth font", () -> Config.smoothFont, v -> Config.smoothFont = v));
        hud.add(new AccentPicker());
        hud.add(new Button("Move HUD", () -> client.setScreen(new HudEditorScreen())));
        pages.add(hud);

        if (!placed) {
            winX = (width - W) / 2;
            winY = (height - H) / 2;
            placed = true;
        }
        clampWindow();
    }

    private void clampWindow() {
        winX = Math.max(0, Math.min(winX, Math.max(0, width - W)));
        winY = Math.max(0, Math.min(winY, Math.max(0, height - H)));
        px = winX;
        py = winY;
    }

    @Override
    public void render(DrawContext c, int mouseX, int mouseY, float delta) {
        int accent = Config.accent();
        c.fill(0, 0, width, height, 0x70000000);

        // окно
        Ui.rrect(c, px - 1, py - 1, W + 2, H + 2, 14, BORDER);
        Ui.rrect(c, px, py, W, H, 13, BG);

        // боковая панель
        Ui.rrect(c, px + 6, py + 6, SIDE - 4, H - 12, 9, SIDE_BG);
        Ui.text(c, textRenderer, "noomi", px + 18, py + 15, accent);
        Ui.text(c, textRenderer, "visuals", px + 18, py + 26, TEXT);

        for (int i = 0; i < TAB_NAMES.length; i++) {
            int ty = py + 48 + i * 24;
            boolean sel = i == tab;
            boolean hov = Ui.in(mouseX, mouseY, px + 12, ty, SIDE - 16, RH);
            if (sel) Ui.capsule(c, px + 12, ty, SIDE - 16, RH, accent);
            else if (hov) Ui.capsule(c, px + 12, ty, SIDE - 16, RH, PANEL_HOVER);
            Ui.textMid(c, textRenderer, TAB_NAMES[i], px + 24, ty, RH, sel ? 0xFFFFFFFF : MUTED);
        }
        Ui.text(c, textRenderer, "RShift - close", px + 18, py + H - 20, 0xFF5E5E70);

        // содержимое вкладки
        int cx = px + SIDE + 10;
        int cw = W - SIDE - 20;
        Ui.text(c, textRenderer, TAB_NAMES[tab], cx + 4, py + 15, TEXT);

        int y = py + 34;
        for (Row r : pages.get(tab)) {
            r.render(c, cx, y, cw, mouseX, mouseY);
            y += r.height();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            for (int i = 0; i < TAB_NAMES.length; i++) {
                int ty = py + 48 + i * 24;
                if (Ui.in(mouseX, mouseY, px + 12, ty, SIDE - 16, RH)) {
                    tab = i;
                    return true;
                }
            }
            int cx = px + SIDE + 10;
            int cw = W - SIDE - 20;
            int y = py + 34;
            for (Row r : pages.get(tab)) {
                if (r.click(cx, y, cw, mouseX, mouseY)) {
                    dragging = r;
                    return true;
                }
                y += r.height();
            }
            // клик по пустому месту окна - тащим окно
            if (Ui.in(mouseX, mouseY, px, py, W, H)) {
                movingWindow = true;
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mouseX);
            return true;
        }
        if (movingWindow) {
            winX += (int) Math.round(dx);
            winY += (int) Math.round(dy);
            clampWindow();
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
        movingWindow = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        Config.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
